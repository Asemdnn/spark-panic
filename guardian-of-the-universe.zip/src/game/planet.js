// Spark Panic 2.0 - Central Living Planet & Aegis Energy Shield

import { audio } from '../engine/audio.js';

export class Planet {
  constructor(canvasOrWidth, maybeHeight, maybeConfig) {
    if (typeof canvasOrWidth === 'number') {
      this.canvas = { width: canvasOrWidth, height: maybeHeight || 600 };
      this.x = canvasOrWidth * 0.5;
      this.y = (maybeHeight || 600) * 0.53;
      if (maybeConfig) this.data = maybeConfig;
    } else {
      this.canvas = canvasOrWidth;
      const w = canvasOrWidth && canvasOrWidth.width ? canvasOrWidth.width : 800;
      const h = canvasOrWidth && canvasOrWidth.height ? canvasOrWidth.height : 600;
      this.x = w * 0.5;
      this.y = h * 0.53;
    }
    this.planetRadius = 75;
    this.shieldRadius = 97;

    this.maxShield = 100;
    this.shield = 100;
    this.maxCoreHp = 100;
    this.coreHp = 100;

    this.outOfCombatTimer = 0;
    this.shieldRegenRate = 18; // HP/sec
    this.rotation = 0;
    this.pulsePhase = 0;

    this.data = null;
    this.shieldRipples = [];
    this.craters = [];
    this.continents = [];
    this.surfaceCities = [];
    this.cityDistressTimer = 0;
    this.cityParticles = [];
    this.fireworks = [];
    this.initCities();
    this.initContinents();
  }

  initCities() {
    this.surfaceCities = [];
    for (let i = 0; i < 4; i++) {
      this.surfaceCities.push({
        index: i,
        angle: i * Math.PI * 0.5,
        spires: [
          { width: 5, height: 3, offset: -6 },
          { width: 8, height: 4, offset: -2 },
          { width: 3, height: 1.2, offset: -0.6 },
          { width: 5, height: 3, offset: 3 }
        ]
      });
    }
  }

  get fireworkParticles() {
    return this.fireworks.filter(f => f.type === 'spark');
  }

  initContinents() {
    this.continents = [];
    const count = 7;
    for (let i = 0; i < count; i++) {
      this.continents.push({
        angle: (i / count) * Math.PI * 2,
        dist: 0.2 + Math.random() * 0.5,
        radius: 0.2 + Math.random() * 0.25,
        tilt: (Math.random() - 0.5) * 0.8
      });
    }
  }

  resize(width, height) {
    this.x = width * 0.5;
    this.y = height * 0.53;
    this.planetRadius = Math.max(68, Math.min(width, height) * 0.115);
    this.shieldRadius = this.planetRadius + 22;
  }

  setPlanet(planetConfig, shieldGridLvl = 0) {
    this.data = planetConfig;
    const bonusPct = shieldGridLvl * 0.22;
    this.maxShield = Math.round(100 * (1 + bonusPct));
    this.shield = this.maxShield;
    this.maxCoreHp = Math.round(100 * (1 + bonusPct));
    this.coreHp = this.maxCoreHp;

    this.outOfCombatTimer = 0;
    this.shieldRegenRate = 18 * (1 + shieldGridLvl * 0.2);
    this.shieldRipples = [];
    this.craters = [];
    this.cityParticles = [];
    this.fireworks = [];
    this.cityDistressTimer = 0;
    this.initCities();
    this.initContinents();
  }

  damage(amount, hitX, hitY) {
    this.outOfCombatTimer = 0;
    const angle = Math.atan2(hitY - this.y, hitX - this.x);

    // Directional shield ripple
    this.shieldRipples.push({
      angle,
      radius: 6,
      maxRadius: 36,
      alpha: 1.0
    });

    if (this.shield > 0) {
      if (this.shield >= amount) {
        this.shield -= amount;
        audio.playShieldHit();
      } else {
        const overflow = amount - this.shield;
        this.shield = 0;
        if (this.engine && this.engine.onShieldBroken) {
          this.engine.onShieldBroken();
        }
        this.coreHp = Math.max(0, this.coreHp - overflow);
        this.addCrater(angle);
        audio.playShieldHit();
      }
    } else {
      this.coreHp = Math.max(0, this.coreHp - amount);
      this.addCrater(angle);
      audio.playShieldHit();
    }
  }

  restoreShield(amount) {
    const prev = this.shield;
    this.shield = Math.min(this.maxShield, this.shield + amount);
    return this.shield - prev;
  }

  addCrater(angle) {
    const r = this.planetRadius * (0.4 + Math.random() * 0.45);
    this.craters.push({
      x: Math.cos(angle) * r,
      y: Math.sin(angle) * r,
      size: 6 + Math.random() * 6,
      alpha: 1.0
    });
    if (this.craters.length > 12) this.craters.shift();
  }

  update(dt, isOverdrive = false) {
    this.rotation += dt * 0.18;
    this.pulsePhase += dt * (isOverdrive ? 6 : 3);
    this.outOfCombatTimer += dt;

    // Shield Regen after 3.5s delay
    if (this.outOfCombatTimer >= 3.5 && this.shield < this.maxShield && this.coreHp > 0) {
      this.shield = Math.min(this.maxShield, this.shield + this.shieldRegenRate * dt);
    }

    // Update shield ripples
    for (let i = this.shieldRipples.length - 1; i >= 0; i--) {
      const rip = this.shieldRipples[i];
      rip.radius += dt * 75;
      rip.alpha = Math.max(0, 1 - (rip.radius / rip.maxRadius));
      if (rip.radius >= rip.maxRadius || rip.alpha <= 0.01) {
        this.shieldRipples.splice(i, 1);
      }
    }

    // Update Surface City Distress Signals & Particles
    const hpRatio = this.coreHp / (this.maxCoreHp || 100);
    this.cityDistressTimer += dt;
    if (hpRatio < 0.70 && this.cityDistressTimer >= (hpRatio < 0.35 ? 0.08 : 0.20)) {
      this.cityDistressTimer = 0;
      const r = this.planetRadius;
      const cityIdx = Math.floor(Math.random() * 4);
      const cityAngle = (cityIdx * Math.PI * 0.5) + this.rotation;
      const cx = this.x + Math.cos(cityAngle) * r;
      const cy = this.y + Math.sin(cityAngle) * r;

      if (hpRatio < 0.35) {
        // Critical: Red emergency strobes & electrical distress arcs
        this.cityParticles.push({
          x: cx,
          y: cy,
          vx: Math.cos(cityAngle) * (25 + Math.random() * 35) + (Math.random() - 0.5) * 20,
          vy: Math.sin(cityAngle) * (25 + Math.random() * 35) + (Math.random() - 0.5) * 20,
          color: Math.random() > 0.5 ? '#ff3366' : '#ffd700',
          size: 1.8 + Math.random() * 1.5,
          alpha: 1.0,
          life: 0.3 + Math.random() * 0.3,
          maxLife: 0.6,
          isArc: Math.random() > 0.35
        });
      } else {
        // Warning: Orange warning beacons and tiny smoke/sparks
        this.cityParticles.push({
          x: cx,
          y: cy,
          vx: Math.cos(cityAngle) * (12 + Math.random() * 18) + (Math.random() - 0.5) * 12,
          vy: Math.sin(cityAngle) * (12 + Math.random() * 18) + (Math.random() - 0.5) * 12,
          color: Math.random() > 0.4 ? '#f97316' : '#94a3b8',
          size: 2.0 + Math.random() * 2.0,
          alpha: 0.8,
          life: 0.4 + Math.random() * 0.4,
          maxLife: 0.8,
          isArc: false
        });
      }
    }

    // Update City Particles
    for (let i = this.cityParticles.length - 1; i >= 0; i--) {
      const p = this.cityParticles[i];
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.life -= dt;
      p.alpha = Math.max(0, p.life / p.maxLife);
      if (p.life <= 0) {
        this.cityParticles.splice(i, 1);
      }
    }

    // Update Fireworks (Shells & Exploding Sparks)
    const colors = ['#00e5ff', '#ffd700', '#e040fb', '#00e676', '#ff3366', '#ffffff'];
    for (let i = this.fireworks.length - 1; i >= 0; i--) {
      const fw = this.fireworks[i];
      if (fw.type === 'shell') {
        fw.x += fw.vx * dt;
        fw.y += fw.vy * dt;
        fw.vx *= 0.98;
        fw.vy *= 0.98;
        fw.fuse -= dt;

        if (fw.fuse <= 0) {
          this.fireworks.splice(i, 1);
          const sparkCount = 16 + Math.floor(Math.random() * 8);
          for (let s = 0; s < sparkCount; s++) {
            const sAng = (s / sparkCount) * Math.PI * 2 + (Math.random() - 0.5) * 0.3;
            const sSpeed = 50 + Math.random() * 110;
            this.fireworks.push({
              type: 'spark',
              x: fw.x,
              y: fw.y,
              vx: Math.cos(sAng) * sSpeed,
              vy: Math.sin(sAng) * sSpeed,
              color: colors[Math.floor(Math.random() * colors.length)],
              size: 2.2 + Math.random() * 1.6,
              alpha: 1.0,
              life: 0.65 + Math.random() * 0.55,
              maxLife: 1.2
            });
          }
        }
      } else if (fw.type === 'spark') {
        fw.x += fw.vx * dt;
        fw.y += fw.vy * dt;
        fw.vx *= 0.94;
        fw.vy *= 0.94;
        fw.life -= dt;
        fw.alpha = Math.max(0, fw.life / fw.maxLife);
        if (fw.life <= 0) {
          this.fireworks.splice(i, 1);
        }
      }
    }
  }

  triggerVictoryFireworks() {
    const colors = ['#00e5ff', '#ffd700', '#e040fb', '#00e676', '#ff3366', '#ffffff'];
    const r = this.planetRadius;

    for (let i = 0; i < 4; i++) {
      const cityAngle = (i * Math.PI * 0.5) + this.rotation;
      for (let s = 0; s < 2; s++) {
        const spread = (Math.random() - 0.5) * 0.45;
        const ang = cityAngle + spread;
        const speed = 120 + Math.random() * 85;
        this.fireworks.push({
          type: 'shell',
          x: this.x + Math.cos(cityAngle) * (r + 4),
          y: this.y + Math.sin(cityAngle) * (r + 4),
          vx: Math.cos(ang) * speed,
          vy: Math.sin(ang) * speed,
          color: colors[(i * 2 + s) % colors.length],
          fuse: 0.35 + Math.random() * 0.45
        });
      }
    }
  }

  // Draw background ring half before planet body
  renderBackRing(ctx) {
    if (!this.data || !this.data.rings) return;
    const r = this.planetRadius;
    ctx.save();
    ctx.translate(this.x, this.y);
    ctx.rotate(-0.35);

    ctx.beginPath();
    ctx.ellipse(0, 0, r * 1.85, r * 0.55, 0, Math.PI, Math.PI * 2);
    ctx.strokeStyle = `${this.data.atmo}88`;
    ctx.lineWidth = 14;
    ctx.stroke();

    ctx.beginPath();
    ctx.ellipse(0, 0, r * 1.72, r * 0.50, 0, Math.PI, Math.PI * 2);
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
    ctx.lineWidth = 3;
    ctx.stroke();

    ctx.restore();
  }

  render(ctx, isOverdrive = false, timeSec = 0, beatPulse = 0, coreCharge = 0) {
    if (!this.data) return;
    const r = this.planetRadius;
    const sr = this.shieldRadius;
    const atmo = this.data.atmo || '#00e5ff';
    const c1 = this.data.color1 || '#0ea5e9';
    const c2 = this.data.color2 || '#10b981';
    const sector = this.sector || (this.data ? this.data.sector : 1) || 1;

    // 1. Atmospheric Outer Halo (modulated by Web Audio Beat-Pulse)
    const haloExtra = 6 * (beatPulse || 0);
    const haloR = sr + 24 + haloExtra;
    const halo = ctx.createRadialGradient(this.x, this.y, r * 0.8, this.x, this.y, haloR);
    halo.addColorStop(0, `${atmo}55`);
    halo.addColorStop(0.7, `${atmo}20`);
    halo.addColorStop(1, 'transparent');
    ctx.fillStyle = halo;
    ctx.beginPath();
    ctx.arc(this.x, this.y, haloR, 0, Math.PI * 2);
    ctx.fill();

    // Sector II: 3 Translucent Volumetric Violet/Magenta Ionized Nebula Clouds
    if (sector === 2) {
      ctx.save();
      const nebulae = [
        { dx: -r * 1.5, dy: -r * 0.9, rad: r * 1.6, col: '#7928ca' },
        { dx: r * 1.4, dy: r * 0.8, rad: r * 1.8, col: '#e040fb' },
        { dx: -r * 0.6, dy: r * 1.5, rad: r * 1.4, col: '#4c1d95' }
      ];
      for (let nIdx = 0; nIdx < nebulae.length; nIdx++) {
        const neb = nebulae[nIdx];
        const driftX = Math.cos(timeSec * 0.15 + nIdx * 2.1) * 24;
        const driftY = Math.sin(timeSec * 0.15 + nIdx * 2.1) * 18;
        const ng = ctx.createRadialGradient(
          this.x + neb.dx + driftX, this.y + neb.dy + driftY, neb.rad * 0.1,
          this.x + neb.dx + driftX, this.y + neb.dy + driftY, neb.rad
        );
        const nebAlpha = Math.min(0.28, 0.14 + (beatPulse || 0) * 0.08);
        ng.addColorStop(0, `rgba(168, 85, 247, ${nebAlpha})`);
        ng.addColorStop(0.6, `rgba(217, 70, 239, ${nebAlpha * 0.6})`);
        ng.addColorStop(1, 'transparent');
        ctx.fillStyle = ng;
        ctx.beginPath();
        ctx.arc(this.x + neb.dx + driftX, this.y + neb.dy + driftY, neb.rad, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }

    // Sector IV: Solar Corona Prominence Loops / Plasma Flares from Planet Limb
    if (sector === 4) {
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      const flareCount = 8;
      for (let f = 0; f < flareCount; f++) {
        const fAng = (f / flareCount) * Math.PI * 2 + (timeSec * 0.2);
        const loopReach = 14 + Math.sin(timeSec * 3 + f * 1.5) * 12;
        const p1x = this.x + Math.cos(fAng - 0.16) * r;
        const p1y = this.y + Math.sin(fAng - 0.16) * r;
        const p2x = this.x + Math.cos(fAng + 0.16) * r;
        const p2y = this.y + Math.sin(fAng + 0.16) * r;
        const ctrlX = this.x + Math.cos(fAng) * (r + loopReach);
        const ctrlY = this.y + Math.sin(fAng) * (r + loopReach);

        ctx.beginPath();
        ctx.moveTo(p1x, p1y);
        ctx.quadraticCurveTo(ctrlX, ctrlY, p2x, p2y);
        ctx.strokeStyle = f % 2 === 0 ? '#ff9100' : '#ffd700';
        ctx.lineWidth = 3.2;
        ctx.shadowColor = '#ff3d00';
        ctx.shadowBlur = 14;
        ctx.stroke();
      }
      // Rising golden starlight embers
      for (let e = 0; e < 6; e++) {
        const eAng = (e / 6) * Math.PI * 2 + (timeSec * 0.45);
        const eDist = r * 0.45 + (Math.sin(timeSec * 2.2 + e * 1.2) * 0.5 + 0.5) * (r * 0.85);
        const ex = this.x + Math.cos(eAng) * eDist;
        const ey = this.y + Math.sin(eAng) * eDist;
        ctx.beginPath();
        ctx.arc(ex, ey, 2.2, 0, Math.PI * 2);
        ctx.fillStyle = '#ffd700';
        ctx.shadowColor = '#ffd700';
        ctx.shadowBlur = 8;
        ctx.fill();
      }
      ctx.restore();
    }

    // 2. Rotating Celestial Planet Body
    ctx.save();
    ctx.beginPath();
    ctx.arc(this.x, this.y, r, 0, Math.PI * 2);
    ctx.clip();

    // Base color
    ctx.fillStyle = c1;
    ctx.fillRect(this.x - r, this.y - r, r * 2, r * 2);

    // Rotating Continents & Biome Swirls
    ctx.save();
    ctx.translate(this.x, this.y);
    ctx.rotate(this.rotation);
    ctx.fillStyle = c2;
    for (const cont of this.continents) {
      const cx = Math.cos(cont.angle) * (r * cont.dist);
      const cy = Math.sin(cont.angle) * (r * cont.dist);
      const cr = r * cont.radius;

      ctx.beginPath();
      ctx.ellipse(cx, cy, cr * 1.3, cr * 0.9, cont.tilt, 0, Math.PI * 2);
      ctx.fill();
    }

    // Impact Craters on surface
    for (const cr of this.craters) {
      ctx.beginPath();
      ctx.arc(cr.x, cr.y, cr.size, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(10, 10, 20, 0.75)';
      ctx.fill();
      ctx.strokeStyle = '#ff3366';
      ctx.lineWidth = 1.2;
      ctx.stroke();
    }
    ctx.restore();

    // Sector I: 2 Counter-Rotating Semi-Transparent Cloud Layers
    if (sector === 1) {
      // Cloud Layer 1 (Drifting forward at rotation * 1.35)
      ctx.save();
      ctx.translate(this.x, this.y);
      ctx.rotate(this.rotation * 1.35);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.22)';
      for (let c = 0; c < 5; c++) {
        const cAng = (c / 5) * Math.PI * 2;
        const cDist = r * (0.22 + (c % 3) * 0.2);
        ctx.beginPath();
        ctx.ellipse(Math.cos(cAng) * cDist, Math.sin(cAng) * cDist, r * 0.45, r * 0.18, cAng + 0.35, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();

      // Cloud Layer 2 (Counter-rotating at -rotation * 0.95)
      ctx.save();
      ctx.translate(this.x, this.y);
      ctx.rotate(-this.rotation * 0.95);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.16)';
      for (let c = 0; c < 4; c++) {
        const cAng = (c / 4) * Math.PI * 2 + 0.5;
        const cDist = r * (0.35 + (c % 2) * 0.25);
        ctx.beginPath();
        ctx.ellipse(Math.cos(cAng) * cDist, Math.sin(cAng) * cDist, r * 0.38, r * 0.15, cAng - 0.3, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }

    // Sector II: Glowing Molten Magma Veins / Volcanic Cracks Pulsing Across Surface
    if (sector === 2) {
      ctx.save();
      ctx.translate(this.x, this.y);
      ctx.rotate(this.rotation * 0.85);
      const mPulse = 0.5 + Math.sin(timeSec * 4) * 0.5;
      ctx.strokeStyle = `rgba(255, 61, 0, ${0.75 + mPulse * 0.25})`;
      ctx.lineWidth = 2.4;
      ctx.shadowColor = '#ff9100';
      ctx.shadowBlur = 10 + mPulse * 8;
      const cracks = [
        [-r * 0.65, -r * 0.2, -r * 0.35, -r * 0.4, -r * 0.1, -r * 0.12, 0, -r * 0.3],
        [-r * 0.25, r * 0.1, r * 0.1, r * 0.32, r * 0.45, r * 0.2, r * 0.62, r * 0.5],
        [r * 0.1, -r * 0.55, r * 0.3, -r * 0.25, r * 0.5, -r * 0.32, r * 0.65, 0]
      ];
      for (const path of cracks) {
        ctx.beginPath();
        ctx.moveTo(path[0], path[1]);
        for (let pt = 2; pt < path.length; pt += 2) {
          ctx.lineTo(path[pt], path[pt + 1]);
        }
        ctx.stroke();
      }
      ctx.restore();
    }

    // 3D Spherical Night-Side Terminator Shadow
    const shadow = ctx.createRadialGradient(
      this.x - r * 0.45, this.y - r * 0.45, r * 0.2,
      this.x, this.y, r * 1.05
    );
    shadow.addColorStop(0, 'rgba(0,0,0,0)');
    shadow.addColorStop(0.55, 'rgba(3,7,18,0.4)');
    shadow.addColorStop(1, 'rgba(1,3,10,0.92)');
    ctx.fillStyle = shadow;
    ctx.fillRect(this.x - r, this.y - r, r * 2, r * 2);

    ctx.restore();

    // Sector I: Shimmering Cyan/Emerald Aurora Borealis Ribbons at North & South Poles
    if (sector === 1) {
      ctx.save();
      const poles = [-r, r];
      for (const poleY of poles) {
        const isNorth = poleY < 0;
        ctx.save();
        ctx.translate(this.x, this.y + poleY);
        ctx.globalCompositeOperation = 'lighter';
        for (let rib = 0; rib < 2; rib++) {
          const col = rib === 0 ? '#00e5ff' : '#00e676';
          ctx.beginPath();
          const span = r * 0.72;
          for (let x = -span; x <= span; x += 6) {
            const wave = Math.sin(timeSec * 2.5 + x * 0.08 + rib * 1.5) * (isNorth ? -10 : 10);
            const y = wave * (1 - Math.abs(x) / span);
            if (x === -span) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
          }
          ctx.strokeStyle = col;
          ctx.lineWidth = 3.2;
          ctx.shadowColor = col;
          ctx.shadowBlur = 12;
          ctx.globalAlpha = 0.65 + Math.sin(timeSec * 2 + rib) * 0.25;
          ctx.stroke();
        }
        ctx.restore();
      }
      ctx.restore();
    }

    // Sector III: Rotating Golden Cybernetic Dyson-Ring Megastructure Segments
    if (sector === 3) {
      ctx.save();
      ctx.translate(this.x, this.y);

      // Subtle gravitational lens distortion ring
      const lensR = r * 1.12 + Math.sin(timeSec * 2) * 3;
      ctx.beginPath();
      ctx.arc(0, 0, lensR, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(0, 229, 255, 0.20)';
      ctx.lineWidth = 2.0;
      ctx.setLineDash([8, 12]);
      ctx.stroke();
      ctx.setLineDash([]);

      // 4 mechanical arc plates orbiting inside Aegis Shield
      const dysonR = (r + sr) * 0.51;
      const dysonRot = timeSec * 0.35;
      ctx.rotate(dysonRot);

      for (let seg = 0; seg < 4; seg++) {
        const startA = (seg / 4) * Math.PI * 2 + 0.15;
        const endA = ((seg + 1) / 4) * Math.PI * 2 - 0.15;

        ctx.beginPath();
        ctx.arc(0, 0, dysonR, startA, endA);
        ctx.strokeStyle = '#ffd700';
        ctx.lineWidth = 4.2;
        ctx.shadowColor = '#ffd700';
        ctx.shadowBlur = 10;
        ctx.stroke();

        // Glowing cyan circuit nodes on plate joints & midpoints
        for (const pct of [0.15, 0.5, 0.85]) {
          const nodeA = startA + (endA - startA) * pct;
          const nx = Math.cos(nodeA) * dysonR;
          const ny = Math.sin(nodeA) * dysonR;
          ctx.beginPath();
          ctx.arc(nx, ny, 2.8, 0, Math.PI * 2);
          ctx.fillStyle = '#00e5ff';
          ctx.shadowColor = '#00e5ff';
          ctx.shadowBlur = 8;
          ctx.fill();
        }
      }
      ctx.restore();
    }

    // Chargeable Planetary Cataclysm Core Overcharge Gauge Arc (radius * 0.48)
    const coreR = r * 0.48;
    const chargePct = Math.min(1.0, Math.max(0, (coreCharge || 0) / 100));

    ctx.save();
    // Circular background track
    ctx.beginPath();
    ctx.arc(this.x, this.y, coreR, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.14)';
    ctx.lineWidth = 3.5;
    ctx.stroke();

    // Charged progress arc
    if (chargePct > 0) {
      const startA = -Math.PI * 0.5;
      const endA = startA + chargePct * Math.PI * 2;
      ctx.beginPath();
      ctx.arc(this.x, this.y, coreR, startA, endA);
      if (chargePct >= 1.0) {
        const strobe = Math.sin(timeSec * 16) > 0;
        ctx.strokeStyle = strobe ? '#ffd700' : '#ff0055';
        ctx.shadowColor = '#ffd700';
        ctx.shadowBlur = 16;
        ctx.lineWidth = 5.0;
      } else {
        ctx.strokeStyle = '#ff9100';
        ctx.shadowColor = '#ff9100';
        ctx.shadowBlur = 8;
        ctx.lineWidth = 3.8;
      }
      ctx.stroke();
    }

    // Center Cataclysm Ready Pulsing Glow & Callout
    if (chargePct >= 1.0) {
      const corePulse = 1.0 + Math.sin(timeSec * 12) * 0.22;
      ctx.beginPath();
      ctx.arc(this.x, this.y, coreR * 0.65 * corePulse, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 215, 0, 0.28)';
      ctx.shadowColor = '#ffd700';
      ctx.shadowBlur = 22;
      ctx.fill();

      ctx.font = 'bold 15px sans-serif';
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('⚡', this.x, this.y);
    }
    ctx.restore();

    // Atmospheric Edge Glow
    ctx.beginPath();
    ctx.arc(this.x, this.y, r, 0, Math.PI * 2);
    ctx.strokeStyle = atmo;
    ctx.lineWidth = 2.5;
    ctx.shadowColor = atmo;
    ctx.shadowBlur = 12;
    ctx.stroke();
    ctx.shadowBlur = 0;

    // 3. Draw Foreground Ring Half
    if (this.data.rings) {
      ctx.save();
      ctx.translate(this.x, this.y);
      ctx.rotate(-0.35);

      ctx.beginPath();
      ctx.ellipse(0, 0, r * 1.85, r * 0.55, 0, 0, Math.PI);
      ctx.strokeStyle = `${atmo}aa`;
      ctx.lineWidth = 14;
      ctx.stroke();

      ctx.beginPath();
      ctx.ellipse(0, 0, r * 1.72, r * 0.50, 0, 0, Math.PI);
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 3;
      ctx.stroke();

      ctx.restore();
    }

    // 3.5. Living Planetary Surface Cyber-Cities on Horizon (4 Cities at 0, 90, 180, 270 deg)
    const hpRatio = this.coreHp / (this.maxCoreHp || 100);
    const isCritical = hpRatio < 0.35;
    const isWarning = hpRatio >= 0.35 && hpRatio <= 0.70;

    for (let i = 0; i < 4; i++) {
      const cityAngle = (i * Math.PI * 0.5) + this.rotation;
      const cx = this.x + Math.cos(cityAngle) * r;
      const cy = this.y + Math.sin(cityAngle) * r;

      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(cityAngle); // +X radially outward, Y tangent to circumference

      // Miniature skyline silhouette
      ctx.fillStyle = '#080d1a';
      // Left building
      ctx.fillRect(0, -6, 5, 3);
      // Center skyscraper spire
      ctx.fillRect(0, -2, 8, 4);
      // Antenna spire
      ctx.fillRect(8, -0.6, 3, 1.2);
      // Right building
      ctx.fillRect(0, 3, 5, 3);

      // Window lights
      let windowColor = '#00e5ff';
      if (isCritical) {
        windowColor = '#ff3366';
      } else if (isWarning) {
        windowColor = (Math.sin(this.pulsePhase * 3 + i) > 0) ? '#f97316' : '#ffd700';
      } else {
        windowColor = (i % 2 === 0) ? '#00e5ff' : '#ffd700';
      }
      ctx.fillStyle = windowColor;
      ctx.fillRect(2, -4.5, 1.2, 1.2);
      ctx.fillRect(4, -1, 1.2, 1.2);
      ctx.fillRect(6, -1, 1.2, 1.2);
      ctx.fillRect(2, 4, 1.2, 1.2);

      // Energy cupola / dome over the city
      ctx.beginPath();
      ctx.ellipse(0, 0, 11, 7, 0, -Math.PI * 0.5, Math.PI * 0.5);
      if (isCritical) {
        const strobe = Math.sin(this.pulsePhase * 9 + i * 2) > 0;
        ctx.fillStyle = strobe ? 'rgba(255, 51, 102, 0.35)' : 'rgba(255, 51, 102, 0.08)';
        ctx.strokeStyle = '#ff3366';
        ctx.lineWidth = 1.4;
      } else if (isWarning) {
        ctx.fillStyle = 'rgba(249, 115, 22, 0.16)';
        ctx.strokeStyle = '#f97316';
        ctx.lineWidth = 1.2;
      } else {
        ctx.fillStyle = 'rgba(0, 229, 255, 0.14)';
        ctx.strokeStyle = (i % 2 === 0) ? '#00e5ff' : '#ffd700';
        ctx.lineWidth = 1.2;
      }
      ctx.fill();
      ctx.stroke();

      // Cyber Beacon Light at Spire Apex
      const beaconX = 11.5;
      ctx.beginPath();
      ctx.arc(beaconX, 0, 1.8, 0, Math.PI * 2);
      if (isCritical) {
        ctx.fillStyle = (Math.sin(this.pulsePhase * 10 + i * 3) > 0) ? '#ff3366' : 'transparent';
      } else if (isWarning) {
        ctx.fillStyle = (Math.sin(this.pulsePhase * 4 + i) > 0) ? '#f97316' : '#ffd700';
      } else {
        const beaconPulse = Math.sin(this.pulsePhase * 2.5 + i);
        ctx.fillStyle = beaconPulse > 0 ? '#00e5ff' : '#ffffff';
      }
      ctx.fill();

      ctx.restore();
    }

    // City Distress Particles & Electrical Arcs
    for (const p of this.cityParticles) {
      ctx.save();
      ctx.globalAlpha = p.alpha;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fillStyle = p.color;
      ctx.shadowColor = p.color;
      ctx.shadowBlur = 6;
      ctx.fill();

      if (p.isArc) {
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(p.x + (Math.random() - 0.5) * 12, p.y + (Math.random() - 0.5) * 12);
        ctx.strokeStyle = p.color;
        ctx.lineWidth = 1.5;
        ctx.stroke();
      }
      ctx.restore();
    }

    // 4. Aegis Energy Shield
    if (this.shield > 0) {
      const shieldPct = this.shield / this.maxShield;
      const pulse = Math.sin(this.pulsePhase) * 1.5;
      const curSr = sr + pulse;
      const shieldColor = isOverdrive ? '#ffd700' : (shieldPct > 0.4 ? '#00e5ff' : '#ff3366');

      // Translucent energy dome
      ctx.beginPath();
      ctx.arc(this.x, this.y, curSr, 0, Math.PI * 2);
      ctx.fillStyle = isOverdrive
        ? 'rgba(255, 215, 0, 0.16)'
        : (shieldPct > 0.4 ? 'rgba(0, 229, 255, 0.14)' : 'rgba(255, 51, 102, 0.18)');
      ctx.fill();

      // Outer boundary ring
      ctx.strokeStyle = shieldColor;
      ctx.lineWidth = isOverdrive ? 3 : 2;
      ctx.shadowColor = shieldColor;
      ctx.shadowBlur = isOverdrive ? 18 : 12;
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Hexagonal Lattice Defense Nodes (brightness modulated by beatPulse)
      const nodeCount = 16;
      const nodePulse = 1.0 + (beatPulse || 0) * 0.8;
      for (let i = 0; i < nodeCount; i++) {
        const ang = (i / nodeCount) * Math.PI * 2 + (this.pulsePhase * 0.1);
        const nx = this.x + Math.cos(ang) * curSr;
        const ny = this.y + Math.sin(ang) * curSr;

        ctx.beginPath();
        ctx.arc(nx, ny, 2.8 * nodePulse, 0, Math.PI * 2);
        ctx.fillStyle = '#ffffff';
        ctx.shadowColor = shieldColor;
        ctx.shadowBlur = 8 * nodePulse;
        ctx.fill();
        ctx.strokeStyle = shieldColor;
        ctx.lineWidth = 1.2;
        ctx.stroke();
      }

      // Directional Hit Ripples
      for (const rip of this.shieldRipples) {
        const hx = this.x + Math.cos(rip.angle) * curSr;
        const hy = this.y + Math.sin(rip.angle) * curSr;

        ctx.beginPath();
        ctx.arc(hx, hy, rip.radius, 0, Math.PI * 2);
        ctx.strokeStyle = isOverdrive ? '#ffd700' : '#00e5ff';
        ctx.globalAlpha = rip.alpha;
        ctx.lineWidth = 2.5;
        ctx.stroke();
        ctx.globalAlpha = 1.0;
      }
    }

    // 5. Celebratory Orbital Fireworks
    for (const fw of this.fireworks) {
      ctx.save();
      ctx.globalAlpha = fw.alpha !== undefined ? fw.alpha : 1.0;
      ctx.beginPath();
      ctx.arc(fw.x, fw.y, fw.size || 2.4, 0, Math.PI * 2);
      ctx.fillStyle = fw.color;
      ctx.shadowColor = fw.color;
      ctx.shadowBlur = 10;
      ctx.fill();
      ctx.restore();
    }
  }
}
