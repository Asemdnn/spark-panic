// Spark Panic 2.5 - Application Bootstrap & Event Controller

import { PLANETS, SECTORS, ALIEN_CLASSES, ARMORY_CONFIG, TROPHIES, GUARDIAN_RANKS, CHASSIS_CONFIG, getDailyAnomalyConfig, TITAN_PROTOCOL_CONFIG, WINGMAN_CONFIG, TURRET_SKINS, ASCENSION_CONFIG, COSMIC_RELICS, STRUCTURE_CONFIG, DEFAULT_SETTINGS, SHIPYARD_PARTS } from './config.js';
import { audio } from './engine/audio.js';
import { saveSystem } from './engine/storage.js';
import { GameEngine } from './game/engine.js';
import { BattleCardGenerator } from './ui/battle-card.js';
import { ICON_SVG } from './ui/icons.js';

// Register PWA Service Worker for Offline Play & Fast Launch
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch(err => {
      console.debug('Service Worker registration notice:', err);
    });
  });
}

window.addEventListener('DOMContentLoaded', () => {
  const canvas = document.getElementById('gameCanvas');
  const engine = new GameEngine(canvas);
  engine.artStyle = saveSystem.getArtStyle ? saveSystem.getArtStyle() : 'astral';

  // Selected Sector & Planet in Star Map
  let selectedSector = 1;
  let selectedPlanetId = 1;

  // Track pointer
  window.addEventListener('pointermove', (e) => {
    engine.pointerX = e.clientX;
    engine.pointerY = e.clientY;
  });

  // Prevent browser context menu on game canvas for zero-latency Right-Click Phase-Parry
  canvas.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    if (engine.state === 'PLAYING') {
      engine.triggerPhaseParry();
    }
  });

  // Canvas Pointer Events: Quick Tap (Nova/Cataclysm), Hold (Overcharge Lance), or Right-Click (Parry)
  canvas.addEventListener('pointerdown', (e) => {
    audio.init();
    if (engine.state === 'PLAYING') {
      // Right-Click: Aegis Phase-Parry Deflection
      if (e.button === 2) {
        engine.triggerPhaseParry();
        return;
      }

      engine.pointerDownTime = performance.now();
      engine.isPointerDown = true;
      engine.chargeProgress = 0;
      engine.turret.isFiring = true;
    }
  });

  window.addEventListener('pointerup', (e) => {
    if (engine.state === 'PLAYING' && engine.isPointerDown) {
      if (engine.isChargingOvercharge && engine.chargeProgress >= 0.50) {
        engine.triggerOverchargeLance();
      } else {
        // Quick Click/Tap (< 0.25s)
        const dx = e.clientX - engine.planet.x;
        const dy = e.clientY - engine.planet.y;
        const dist = Math.hypot(dx, dy);

        // If clicked inside planet core when Cataclysm is ready (100%), unleash Planetary Cataclysm!
        if (dist <= engine.planet.planetRadius * 0.7 && engine.coreCharge >= 100) {
          engine.triggerPlanetaryCataclysm();
        } else if (dist > engine.planet.shieldRadius + 8) {
          engine.triggerSparkNova(e.clientX, e.clientY);
        }
      }

      engine.isChargingOvercharge = false;
      engine.chargeProgress = 0;
      engine.isPointerDown = false;
      engine.turret.isFiring = false;
    }
  });

  // Keyboard Hotkeys
  window.addEventListener('keydown', (e) => {
    const key = e.key.toUpperCase();

    if (e.code === 'Space') {
      e.preventDefault();
      audio.init();
      if (engine.state === 'PLAYING') {
        engine.triggerSparkNova(engine.pointerX, engine.pointerY);
      }
    } else if (e.code === 'ShiftLeft' || e.code === 'ShiftRight' || key === 'C') {
      if (engine.state === 'PLAYING') {
        engine.triggerPhaseParry();
      }
    } else if (key === 'Q' || key === '1') {
      if (engine.waveDraftPending) {
        engine.selectDraftPerk(0);
      } else if (engine.state === 'PLAYING') {
        engine.skills.useSkillQ(engine.turret.angle);
      }
    } else if (key === 'W' || key === '2') {
      if (engine.waveDraftPending) {
        engine.selectDraftPerk(1);
      } else if (engine.state === 'PLAYING') {
        engine.skills.useSkillW(engine.planet.x, engine.planet.y);
      }
    } else if (key === 'E' || key === '3') {
      if (engine.waveDraftPending) {
        engine.selectDraftPerk(2);
      } else if (engine.state === 'PLAYING') {
        engine.skills.useSkillE(engine.planet, (gained) => {
          engine.novaCharges = Math.min(engine.maxNovaCharges, engine.novaCharges + gained);
        });
      }
    } else if (key === 'T') {
      engine.turret.autoFire = !engine.turret.autoFire;
    } else if (key === 'P' || key === 'ESCAPE') {
      if (engine.isTutorialActive) {
        engine.skipTutorial();
      } else {
        togglePause();
      }
    } else if (key === 'H') {
      if (engine.state !== 'PLAYING') {
        hideAllModals();
        engine.startCampaignPlanet(1);
      }
      engine.startTutorial();
    } else if (key === 'M') {
      const isMuted = audio.toggleMute();
      const muteBtn = document.getElementById('btnMute');
      if (muteBtn) muteBtn.innerHTML = ICON_SVG.volume(isMuted, 'w-4 h-4');
    } else if (key === 'B') {
      const isBgm = audio.toggleBgm();
      updateBgmButton(isBgm);
    } else if (key === 'R' || key === '4') {
      if (engine.state === 'PLAYING') {
        engine.deployStructure();
      } else if (engine.state === 'DEFEAT' || engine.state === 'PAUSED') {
        restartCurrent();
      }
    } else if (key === 'F' || key === '5') {
      if (engine.state === 'PLAYING') {
        engine.triggerPlanetaryCataclysm();
      }
    } else if (key === 'O') {
      openSettingsModal();
    }
  });

  function updateBgmButton(isEnabled) {
    const btn = document.getElementById('btnBgm');
    if (btn) {
      btn.innerHTML = ICON_SVG.music(isEnabled, 'w-4 h-4');
      btn.classList.toggle('text-cosmic-magenta', isEnabled);
      btn.classList.toggle('text-slate-500', !isEnabled);
      btn.title = `Toggle Synthwave BGM (B) - ${isEnabled ? 'ON' : 'OFF'}`;
    }
  }

  // Initialize audio button visual states
  updateBgmButton(audio.isBgmEnabled);

  // Bottom Tactical Deck Buttons
  document.getElementById('btnQuickNova')?.addEventListener('click', () => {
    audio.init();
    if (engine.state === 'PLAYING') {
      engine.triggerQuickNova();
    }
  });
  document.getElementById('btnSkillQ')?.addEventListener('click', () => {
    if (engine.state === 'PLAYING') engine.skills.useSkillQ(engine.turret.angle);
  });
  document.getElementById('btnSkillW')?.addEventListener('click', () => {
    if (engine.state === 'PLAYING') engine.skills.useSkillW(engine.planet.x, engine.planet.y);
  });
  document.getElementById('btnSkillE')?.addEventListener('click', () => {
    if (engine.state === 'PLAYING') {
      engine.skills.useSkillE(engine.planet, (gained) => {
        engine.novaCharges = Math.min(engine.maxNovaCharges, engine.novaCharges + gained);
      });
    }
  });
  document.getElementById('btnSkillR')?.addEventListener('click', () => {
    if (engine.state === 'PLAYING') {
      engine.deployStructure();
    }
  });
  document.getElementById('btnParry')?.addEventListener('click', () => {
    audio.init();
    if (engine.state === 'PLAYING') {
      engine.triggerPhaseParry();
    }
  });
  document.getElementById('btnCataclysm')?.addEventListener('click', () => {
    if (engine.state === 'PLAYING') {
      engine.triggerPlanetaryCataclysm();
    }
  });
  document.getElementById('btnAutoFire')?.addEventListener('click', () => {
    engine.turret.autoFire = !engine.turret.autoFire;
  });

  // v2.8 Tactical Command Draft Modal Wiring
  const modalWaveDraft = document.getElementById('modalWaveDraft');
  const draftCardsContainer = document.getElementById('draftCardsContainer');
  const hudDraftPerks = document.getElementById('hudDraftPerks');

  engine.onShowWaveDraftModal = (options, nextWaveNum) => {
    if (!modalWaveDraft || !draftCardsContainer) return;
    const waveNumEl = document.getElementById('draftWaveNum');
    if (waveNumEl) waveNumEl.textContent = `WAVE ${nextWaveNum}`;

    draftCardsContainer.innerHTML = options.map((perk, idx) => {
      const isSyn = !!perk.isSynergy;
      const borderClass = isSyn
        ? 'border-2 border-amber-400 bg-amber-950/40 shadow-[0_0_25px_rgba(251,191,36,0.5)] hover:border-amber-300 hover:shadow-[0_0_35px_rgba(251,191,36,0.7)]'
        : 'border border-cosmic-cyan/40 hover:border-cosmic-cyan hover:shadow-[0_0_25px_rgba(0,229,255,0.4)]';
      const badgeClass = isSyn
        ? 'bg-amber-400/20 text-amber-300 border border-amber-400/60'
        : 'bg-cosmic-cyan/20 text-cosmic-cyan border border-cosmic-cyan/40';
      const titleColor = isSyn ? 'text-amber-300' : 'text-cosmic-cyan';
      const btnClass = isSyn
        ? 'bg-amber-500/25 text-amber-300 border border-amber-400/50 group-hover:bg-amber-400 group-hover:text-slate-950 shadow-[0_0_12px_rgba(251,191,36,0.3)]'
        : 'bg-cosmic-cyan/15 text-cosmic-cyan border border-cosmic-cyan/30 group-hover:bg-cosmic-cyan group-hover:text-slate-950';
      const btnText = isSyn ? '🌟 EVOLVE WEAPON' : 'SELECT REINFORCEMENT';

      return `
      <button class="draft-card group relative p-4 rounded-2xl glass-card ${borderClass} transition-all cursor-pointer flex flex-col items-center text-center text-white" data-draft-idx="${idx}">
        <div class="absolute top-2.5 left-2.5 text-[10px] font-orbitron font-extrabold px-2 py-0.5 rounded-full ${badgeClass}">
          [${idx + 1}]
        </div>
        ${isSyn ? `<div class="absolute top-2.5 right-2.5 text-[9px] font-orbitron font-black px-2 py-0.5 rounded-full bg-amber-500 text-slate-950 shadow-[0_0_10px_#f59e0b] animate-pulse">🌟 SYNERGY</div>` : ''}
        <div class="text-3xl md:text-4xl my-2 group-hover:scale-110 transition duration-200">${perk.icon}</div>
        <h4 class="font-orbitron font-black text-sm md:text-base ${titleColor} mb-1">${perk.name}</h4>
        ${isSyn && perk.synergyWith ? `<div class="text-[9px] font-orbitron font-bold text-amber-400/90 mb-1.5">⚡ ${perk.synergyWith}</div>` : ''}
        <p class="text-xs text-slate-300 leading-relaxed">${perk.desc}</p>
        <div class="mt-3.5 w-full py-1.5 rounded-xl font-orbitron font-extrabold text-[10px] tracking-wider ${btnClass} transition">
          ${btnText}
        </div>
      </button>
      `;
    }).join('');

    draftCardsContainer.querySelectorAll('.draft-card').forEach(card => {
      card.addEventListener('click', () => {
        const idx = parseInt(card.dataset.draftIdx, 10);
        engine.selectDraftPerk(idx);
      });
    });

    modalWaveDraft.classList.remove('hidden');
  };

  engine.onHideWaveDraftModal = () => {
    if (modalWaveDraft) modalWaveDraft.classList.add('hidden');
  };

  engine.onUpdateDraftBadges = (perks) => {
    if (!hudDraftPerks) return;
    hudDraftPerks.innerHTML = perks.map(p => {
      const isSyn = !!p.isSynergy;
      const borderClass = isSyn
        ? 'border-amber-400/60 text-amber-300 shadow-[0_0_12px_rgba(251,191,36,0.4)]'
        : 'border-cosmic-cyan/35 text-cosmic-cyan shadow-[0_0_8px_rgba(0,229,255,0.25)]';
      return `
      <div class="glass-panel px-2.5 py-1 rounded-xl flex items-center gap-1.5 ${borderClass} text-xs font-orbitron" title="${p.name}: ${p.desc}">
        <span class="text-sm">${p.icon}</span>
        <span class="text-[9px] font-bold ${isSyn ? 'text-amber-300' : 'text-cosmic-cyan'} hidden sm:inline">${p.name.split(' ')[0]}</span>
      </div>
      `;
    }).join('');
  };

  // Visual Art Style Switcher (v3.1)
  function updateArtStyleButton(style) {
    const btn = document.getElementById('btnArtStyle');
    if (!btn) return;
    const labels = {
      astral: '🎨 STYLE: ASTRAL',
      vector: '🕹️ STYLE: VECTOR',
      comic: '💥 STYLE: COMIC'
    };
    btn.textContent = labels[style] || '🎨 STYLE: ASTRAL';
    btn.setAttribute('data-art-style', style);
  }

  function cycleArtStyle() {
    audio.init();
    const current = saveSystem.getArtStyle ? saveSystem.getArtStyle() : 'astral';
    const order = ['astral', 'vector', 'comic'];
    const idx = order.indexOf(current);
    const next = order[(idx + 1) % order.length];
    if (saveSystem.setArtStyle) {
      saveSystem.setArtStyle(next);
    }
    engine.artStyle = next;
    updateArtStyleButton(next);
    syncSettingsUI();
    const toastMap = { astral: '💎 ASTRAL', vector: '🕹️ VECTOR', comic: '💥 COMIC' };
    engine.showToast(`🎨 ART STYLE: ${toastMap[next]}`, '#00e5ff');
  }

  updateArtStyleButton(engine.artStyle);

  // Top HUD Controls
  document.getElementById('btnArtStyle')?.addEventListener('click', () => {
    cycleArtStyle();
  });
  document.getElementById('btnSettings')?.addEventListener('click', () => {
    openSettingsModal();
  });
  document.getElementById('btnTutorial')?.addEventListener('click', () => {
    audio.init();
    if (engine.state !== 'PLAYING') {
      hideAllModals();
      engine.startCampaignPlanet(1);
    }
    engine.startTutorial();
  });
  document.getElementById('btnSkipTutorial')?.addEventListener('click', () => {
    engine.skipTutorial();
  });
  document.getElementById('btnTutorialComplete')?.addEventListener('click', () => {
    engine.completeTutorial();
  });

  document.getElementById('btnBgm')?.addEventListener('click', () => {
    audio.init();
    const isBgm = audio.toggleBgm();
    updateBgmButton(isBgm);
  });
  document.getElementById('btnMute')?.addEventListener('click', () => {
    audio.init();
    const isMuted = audio.toggleMute();
    const muteBtn = document.getElementById('btnMute');
    if (muteBtn) muteBtn.innerHTML = ICON_SVG.volume(isMuted, 'w-4 h-4');
  });
  document.getElementById('btnPause')?.addEventListener('click', () => {
    togglePause();
  });

  // Title Command Deck Controls
  document.getElementById('btnStartCampaign')?.addEventListener('click', () => {
    audio.init();
    openStarMap();
  });
  document.getElementById('btnTitleTitanProtocol')?.addEventListener('click', () => {
    audio.init();
    hideAllModals();
    engine.startTitanProtocol();
  });
  document.getElementById('btnTitleDailyAnomaly')?.addEventListener('click', () => {
    audio.init();
    openDailyAnomalyModal();
  });
  document.getElementById('btnStartEndless')?.addEventListener('click', () => {
    audio.init();
    hideAllModals();
    engine.startEndless();
  });
  document.getElementById('btnOpenArmory')?.addEventListener('click', () => {
    audio.init();
    openArmory();
  });
  document.getElementById('btnOpenCodex')?.addEventListener('click', () => {
    audio.init();
    openCodex();
  });

  // Star Map Navigation & Launch
  document.getElementById('btnStarMapTitanProtocol')?.addEventListener('click', () => {
    audio.init();
    hideAllModals();
    engine.startTitanProtocol();
  });
  document.getElementById('btnAscension')?.addEventListener('click', () => {
    handleAscensionClick();
  });
  document.getElementById('btnArmoryAscension')?.addEventListener('click', () => {
    handleAscensionClick();
  });
  document.getElementById('btnStarMapDailyAnomaly')?.addEventListener('click', () => {
    audio.init();
    openDailyAnomalyModal();
  });
  document.getElementById('btnStarMapBack')?.addEventListener('click', () => {
    openTitle();
  });
  document.getElementById('btnLaunchMission')?.addEventListener('click', () => {
    audio.init();
    hideAllModals();
    engine.startCampaignPlanet(selectedPlanetId);
  });

  // v3.0 Incursion Quick-Launch Button
  document.getElementById('btnStarMapIncursion')?.addEventListener('click', () => {
    audio.init();
    const activeIncursion = saveSystem.getActiveIncursion ? saveSystem.getActiveIncursion() : null;
    if (activeIncursion && activeIncursion.active) {
      hideAllModals();
      engine.startCampaignPlanet(activeIncursion.planetId);
      const p = PLANETS.find(pl => pl.id === activeIncursion.planetId) || PLANETS[0];
      engine.showToast(`🚨 DEFENDING INCURSION: ${p.name.toUpperCase()}! 2X SHARDS!`, '#ff3366');
    }
  });

  // Daily Cosmic Anomaly Modal Controls
  document.getElementById('btnDailyAnomalyClose')?.addEventListener('click', () => {
    document.getElementById('modalDailyAnomaly')?.classList.add('hidden');
  });
  document.getElementById('btnLaunchDailyAnomaly')?.addEventListener('click', () => {
    audio.init();
    hideAllModals();
    engine.startDailyAnomaly();
  });

  // Sector Tab Filtering
  const sectorTabs = document.querySelectorAll('.sector-tab');
  sectorTabs.forEach(tab => {
    tab.addEventListener('click', (e) => {
      audio.init();
      sectorTabs.forEach(t => {
        t.classList.remove('active', 'bg-cosmic-cyan/20', 'text-cosmic-cyan', 'border-cosmic-cyan');
        t.classList.add('bg-slate-900/50', 'text-slate-400', 'border-slate-800');
      });
      e.currentTarget.classList.add('active', 'bg-cosmic-cyan/20', 'text-cosmic-cyan', 'border-cosmic-cyan');
      e.currentTarget.classList.remove('bg-slate-900/50', 'text-slate-400', 'border-slate-800');

      selectedSector = parseInt(e.currentTarget.getAttribute('data-sector'), 10);
      const firstPlanet = PLANETS.find(p => p.sector === selectedSector);
      if (firstPlanet) selectedPlanetId = firstPlanet.id;
      drawStarMap();
    });
  });

  // Armory Close & Refund All Tech
  document.getElementById('btnArmoryClose')?.addEventListener('click', () => {
    document.getElementById('modalArmory').classList.add('hidden');
    updateTitleStats();
  });
  document.getElementById('btnRefundTech')?.addEventListener('click', () => {
    audio.init();
    const refunded = saveSystem.refundAllTech();
    renderArmoryGrid();
    renderChassisDeck();
    renderShipyardDeck();
    renderWingmanDeck();
    renderTurretSkinDeck();
    renderRelicsDeck();
    engine.applyUpgrades();
    engine.showToast(`REFUNDED ${refunded} STAR SHARDS!`, '#00e676');
  });

  // Codex Close & Save Backup/Import
  document.getElementById('btnCodexClose')?.addEventListener('click', () => {
    document.getElementById('modalCodex').classList.add('hidden');
  });
  document.getElementById('btnExportSave')?.addEventListener('click', () => {
    audio.init();
    const code = saveSystem.exportSaveCode();
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(code).then(() => {
        engine.showToast('SAVE CODE COPIED TO CLIPBOARD!', '#00e5ff');
      }).catch(() => {
        prompt('Copy your quantum save code:', code);
      });
    } else {
      prompt('Copy your quantum save code:', code);
    }
  });
  document.getElementById('btnImportSave')?.addEventListener('click', () => {
    audio.init();
    const input = document.getElementById('inputImportSave');
    const raw = input ? input.value.trim() : '';
    if (!raw) {
      engine.showToast('PLEASE PASTE A SAVE CODE FIRST!', '#ff3366');
      return;
    }
    const success = saveSystem.importSaveCode(raw);
    if (success) {
      if (input) input.value = '';
      engine.applyUpgrades();
      updateTitleStats();
      renderCodexList();
      const shardsEl = document.getElementById('starMapShards');
      if (shardsEl) shardsEl.textContent = saveSystem.data.shards.toLocaleString();
      engine.showToast('SAVE DATA RESTORED SUCCESSFULLY!', '#00e676');
    } else {
      engine.showToast('INVALID OR CORRUPTED SAVE CODE!', '#ff3366');
    }
  });

  // Victory Modal Actions
  document.getElementById('btnVictoryNext')?.addEventListener('click', () => {
    audio.init();
    hideAllModals();
    if (engine.isTitanProtocolMode || engine.isDailyAnomalyMode) {
      openStarMap();
    } else {
      const nextPlanet = Math.min(20, engine.currentPlanetId + 1);
      engine.startCampaignPlanet(nextPlanet);
    }
  });
  document.getElementById('btnVictoryRetry')?.addEventListener('click', () => {
    audio.init();
    hideAllModals();
    if (engine.isTitanProtocolMode) {
      engine.startTitanProtocol();
    } else if (engine.isDailyAnomalyMode) {
      engine.startDailyAnomaly();
    } else {
      engine.startCampaignPlanet(engine.currentPlanetId);
    }
  });
  document.getElementById('btnVictoryMap')?.addEventListener('click', () => {
    audio.init();
    openStarMap();
  });

  // Defeat Modal Actions
  document.getElementById('btnDefeatRetry')?.addEventListener('click', () => {
    audio.init();
    hideAllModals();
    if (engine.isTitanProtocolMode) engine.startTitanProtocol();
    else if (engine.isDailyAnomalyMode) engine.startDailyAnomaly();
    else if (engine.isEndlessMode) engine.startEndless();
    else engine.startCampaignPlanet(engine.currentPlanetId);
  });
  document.getElementById('btnDefeatArmory')?.addEventListener('click', () => {
    audio.init();
    openArmory();
  });
  document.getElementById('btnDefeatMap')?.addEventListener('click', () => {
    audio.init();
    openStarMap();
  });

  // Tactical Pause Actions
  document.getElementById('btnResume')?.addEventListener('click', () => {
    togglePause();
  });
  document.getElementById('btnPauseRestart')?.addEventListener('click', () => {
    restartCurrent();
  });
  document.getElementById('btnPauseStarMap')?.addEventListener('click', () => {
    openStarMap();
  });

  function togglePause() {
    if (engine.state === 'PLAYING') {
      engine.state = 'PAUSED';
      document.getElementById('modalPause').classList.remove('hidden');
    } else if (engine.state === 'PAUSED') {
      engine.state = 'PLAYING';
      document.getElementById('modalPause').classList.add('hidden');
    }
  }

  function restartCurrent() {
    hideAllModals();
    if (engine.isTitanProtocolMode) engine.startTitanProtocol();
    else if (engine.isDailyAnomalyMode) engine.startDailyAnomaly();
    else if (engine.isEndlessMode) engine.startEndless();
    else engine.startCampaignPlanet(engine.currentPlanetId);
  }

  function hideAllModals() {
    const modals = [
      'modalTitle', 'modalStarMap', 'modalArmory', 'modalCodex',
      'modalVictory', 'modalDefeat', 'modalPause', 'modalDailyAnomaly',
      'modalSettings', 'modalBattleCard'
    ];
    modals.forEach(id => {
      const el = document.getElementById(id);
      if (el) el.classList.add('hidden');
    });
  }

  function openDailyAnomalyModal() {
    const modal = document.getElementById('modalDailyAnomaly');
    if (!modal) return;
    modal.classList.remove('hidden');

    const dateKey = new Date().toISOString().slice(0, 10);
    const cfg = getDailyAnomalyConfig(dateKey);

    // Date badge
    const dateBadge = document.getElementById('dailyDateBadge');
    if (dateBadge) dateBadge.textContent = cfg.dateKey;

    // Target planet
    const p = cfg.planet;
    const sectorTag = document.getElementById('dailySectorTag');
    if (sectorTag) sectorTag.textContent = `SECTOR ${'I'.repeat(p.sector)}`;
    const pName = document.getElementById('dailyPlanetName');
    if (pName) pName.textContent = p.name.toUpperCase();
    const pTitle = document.getElementById('dailyPlanetTitle');
    if (pTitle) pTitle.textContent = p.title;

    // Target planet preview canvas
    const pCanvas = document.getElementById('dailyPlanetCanvas');
    if (pCanvas) {
      const pCtx = pCanvas.getContext('2d');
      pCtx.clearRect(0, 0, 56, 56);

      const grad = pCtx.createRadialGradient(20, 20, 4, 28, 28, 26);
      grad.addColorStop(0, p.color2);
      grad.addColorStop(0.7, p.color1);
      grad.addColorStop(1, '#050814');

      pCtx.beginPath();
      pCtx.arc(28, 28, 22, 0, Math.PI * 2);
      pCtx.fillStyle = grad;
      pCtx.fill();

      pCtx.strokeStyle = p.atmo;
      pCtx.lineWidth = 2;
      pCtx.shadowColor = p.atmo;
      pCtx.shadowBlur = 6;
      pCtx.stroke();
      pCtx.shadowBlur = 0;
    }

    // Active Hazard
    const hazardEl = document.getElementById('dailyHazardLabel');
    if (hazardEl) {
      hazardEl.textContent = `${cfg.hazard.icon} ${cfg.hazard.name}`;
      hazardEl.title = cfg.hazard.desc;
    }

    // 2 Mutator Cards
    const container = document.getElementById('dailyMutatorsContainer');
    if (container) {
      container.innerHTML = '';
      cfg.mutators.forEach(m => {
        const card = document.createElement('div');
        card.className = 'glass-card p-3 rounded-2xl flex items-start gap-2.5 border border-slate-700/60';
        card.innerHTML = `
          <span class="text-xl p-1.5 rounded-xl bg-slate-950/80 border border-slate-800 shrink-0">${m.icon}</span>
          <div>
            <div class="font-orbitron font-bold text-xs" style="color: ${m.color}">${m.name}</div>
            <div class="text-[10px] text-slate-300 mt-0.5 leading-snug">${m.desc}</div>
          </div>
        `;
        container.appendChild(card);
      });
    }

    // Today's Best Score
    const bestScore = saveSystem.getDailyBest(cfg.dateKey);
    const bestEl = document.getElementById('dailyBestScore');
    if (bestEl) {
      bestEl.textContent = `${bestScore.toLocaleString()} pts`;
    }

    // Daily Bonus Claimed status
    const claimed = saveSystem.isDailyClaimed(cfg.dateKey);
    const bonusEl = document.getElementById('dailyBonusStatus');
    if (bonusEl) {
      if (claimed) {
        bonusEl.innerHTML = `<span class="text-cosmic-mint font-orbitron font-extrabold text-[11px]">✓ CLAIMED TODAY</span>`;
      } else {
        bonusEl.innerHTML = `<span class="flex items-center justify-end gap-1 font-orbitron font-extrabold text-cosmic-gold">+150 ${ICON_SVG.shard('w-3.5 h-3.5 text-cosmic-gold')}</span>`;
      }
    }
  }

  function openTitle() {
    hideAllModals();
    engine.state = 'TITLE';
    updateTitleStats();
    document.getElementById('modalTitle').classList.remove('hidden');
  }

  function updateTitleStats() {
    const rank = saveSystem.getGuardianRank();
    const rankEl = document.getElementById('titleGuardianRank');
    if (rankEl) {
      rankEl.textContent = rank.title;
      rankEl.style.color = rank.color;
    }
    const totalStars = saveSystem.getTotalStars();
    const starsEl = document.getElementById('titleTotalStars');
    if (starsEl) {
      starsEl.innerHTML = `<span class="flex items-center gap-1.5">${totalStars} / 60 ${ICON_SVG.star('w-4 h-4 text-cosmic-gold')}</span>`;
    }
    const bestWave = saveSystem.data.endlessBestWave || 0;
    const bestScore = saveSystem.data.endlessHighScore || 0;
    const recordEl = document.getElementById('titleRecordStats');
    if (recordEl) {
      recordEl.textContent = `Wave ${bestWave} • ${bestScore.toLocaleString()} pts`;
    }

    const titanRecordEl = document.getElementById('titleTitanRecordStats');
    if (titanRecordEl) {
      if (saveSystem.data.bestBossRushTime && saveSystem.data.bestBossRushTime > 0) {
        titanRecordEl.textContent = `Cleared • ${saveSystem.data.bestBossRushTime.toFixed(1)}s`;
      } else {
        titanRecordEl.textContent = 'Not Cleared';
      }
    }

    // Ascension HUD Badge
    const tier = saveSystem.data.ascensionTier || 0;
    const hudAscension = document.getElementById('hudAscensionBadge');
    const hudAscensionLabel = document.getElementById('hudAscensionLabel');
    if (hudAscension && hudAscensionLabel) {
      if (tier > 0) {
        hudAscension.classList.remove('hidden');
        hudAscensionLabel.textContent = `ASCENSION ${'I'.repeat(tier)}`;
      } else {
        hudAscension.classList.add('hidden');
      }
    }
  }

  function handleAscensionClick() {
    audio.init();
    const canAscend = saveSystem.canAscend();
    const currentTier = saveSystem.data.ascensionTier || 0;
    const nextTier = currentTier + 1;

    if (!canAscend) {
      engine.showToast('ASCENSION REQUIRES 45+ LIBERATED STARS OR LIBERATING ALL 20 PLANETS!', '#ff3366');
      return;
    }

    if (currentTier >= ASCENSION_CONFIG.maxTier) {
      engine.showToast(`MAXIMUM ASCENSION TIER REACHED (TIER ${ASCENSION_CONFIG.maxTier})!`, '#ffd700');
      return;
    }

    const bonusPct = nextTier * 25;
    const scorePct = nextTier * 20;
    const confirmMsg = `🌌 INITIATE HYPERDRIVE ASCENSION TO TIER ${nextTier}?\n\n` +
      `• Liberated Stars & Planetary Conquest progress will reset to Planet 1\n` +
      `• Invading Aliens receive +20% HP & Speed scaling\n` +
      `• Star Shard yield increased by +${bonusPct}%\n` +
      `• Mission Score yield increased by +${scorePct}%\n` +
      `• Turret Chassis, Upgrades, AI Wingman, Trophies & Skins are 100% PRESERVED!\n\n` +
      `Are you ready to ascend, Commander?`;

    if (confirm(confirmMsg)) {
      const res = saveSystem.ascend();
      if (res.success) {
        audio.playVictory();
        engine.applyUpgrades();
        updateTitleStats();
        openStarMap();
        renderArmoryGrid();
        renderChassisDeck();
        renderShipyardDeck();
        renderWingmanDeck();
        renderTurretSkinDeck();
        updateArmoryAscensionBtn();
        engine.showToast(`🌌 HYPERDRIVE ASCENSION TIER ${nextTier} INITIATED!`, '#e040fb');
      }
    }
  }

  function openStarMap() {
    hideAllModals();
    engine.state = 'STARMAP';
    document.getElementById('modalStarMap').classList.remove('hidden');
    document.getElementById('starMapShards').textContent = saveSystem.data.shards.toLocaleString();

    const tier = saveSystem.data.ascensionTier || 0;
    const starMapAscensionLabel = document.getElementById('starMapAscensionLabel');
    if (starMapAscensionLabel) {
      starMapAscensionLabel.textContent = tier > 0 ? `ASCENSION ${'I'.repeat(tier)}` : 'ASCENSION';
    }

    // Default to sector of highest unlocked planet
    const unlocked = saveSystem.data.unlockedPlanet || 1;
    const targetPlanet = PLANETS.find(p => p.id === unlocked) || PLANETS[0];
    selectedSector = targetPlanet.sector;
    selectedPlanetId = targetPlanet.id;

    // Activate tab
    const tabs = document.querySelectorAll('.sector-tab');
    tabs.forEach(t => {
      if (parseInt(t.getAttribute('data-sector'), 10) === selectedSector) {
        t.classList.add('active', 'bg-cosmic-cyan/20', 'text-cosmic-cyan', 'border-cosmic-cyan');
        t.classList.remove('bg-slate-900/50', 'text-slate-400', 'border-slate-800');
      } else {
        t.classList.remove('active', 'bg-cosmic-cyan/20', 'text-cosmic-cyan', 'border-cosmic-cyan');
        t.classList.add('bg-slate-900/50', 'text-slate-400', 'border-slate-800');
      }
    });

    // Incursion Quick-Launch Button in Control Bar
    const incursionBtn = document.getElementById('btnStarMapIncursion');
    const incursionLabel = document.getElementById('starMapIncursionLabel');
    const activeIncursion = saveSystem.getActiveIncursion ? saveSystem.getActiveIncursion() : null;
    if (incursionBtn && incursionLabel) {
      if (activeIncursion && activeIncursion.active) {
        const incursionPlanet = PLANETS.find(p => p.id === activeIncursion.planetId) || PLANETS[0];
        incursionLabel.textContent = `🚨 DEFEND INCURSION: ${incursionPlanet.name.toUpperCase()} (2x ✦)`;
        incursionBtn.classList.remove('hidden');
      } else {
        incursionBtn.classList.add('hidden');
      }
    }

    drawStarMap();
  }

  function drawStarMap() {
    renderStarMapPlanets();
    updateTacticalBriefing();
    updateSectorLiberationBar();
  }

  function updateSectorLiberationBar() {
    const bar = document.getElementById('sectorLiberationBar');
    if (!bar) return;
    bar.innerHTML = '';

    const bonuses = engine.getSectorLiberationBonuses ? engine.getSectorLiberationBonuses() : { sector1: false, sector2: false, sector3: false, sector4: false };
    const starsData = saveSystem?.data?.planetStars || {};

    const SECTOR_INFO = [
      { id: 1, name: 'SEC I', title: 'Inner Sanctuaries', bonus: '+10% Shield & Core HP', active: bonuses.sector1, start: 1, end: 5 },
      { id: 2, name: 'SEC II', title: 'Nebula Frontier', bonus: '+12% Nova Blast Radius', active: bonuses.sector2, start: 6, end: 10 },
      { id: 3, name: 'SEC III', title: 'Dark Rift', bonus: '-10% Skill Cooldowns', active: bonuses.sector3, start: 11, end: 15 },
      { id: 4, name: 'SEC IV', title: 'Sol Genesis', bonus: '+20% Shards & Score Mult', active: bonuses.sector4, start: 16, end: 20 }
    ];

    for (const sec of SECTOR_INFO) {
      let secStars = 0;
      let liberatedCount = 0;
      for (let p = sec.start; p <= sec.end; p++) {
        const s = starsData[p] || 0;
        secStars += s;
        if (s >= 1) liberatedCount++;
      }
      const isMastered = secStars >= 15;
      const isLiberated = sec.active || liberatedCount >= 5;

      const card = document.createElement('div');
      card.className = `glass-card p-2 rounded-xl flex flex-col justify-between border cursor-pointer transition ${
        selectedSector === sec.id
          ? 'border-cosmic-cyan ring-1 ring-cosmic-cyan/40 bg-slate-900/80 shadow-md'
          : (isLiberated ? 'border-cosmic-gold/40 bg-slate-950/70 hover:border-cosmic-gold' : 'border-slate-800 bg-slate-950/50 hover:border-slate-700')
      }`;

      card.innerHTML = `
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-1.5">
            <span class="text-[10px] font-orbitron font-black text-white">${sec.name}</span>
            <span class="text-[8px] font-orbitron font-bold text-cosmic-gold">★ ${secStars}/15</span>
          </div>
          <span class="text-[8px] font-orbitron font-black px-1.5 py-0.5 rounded ${
            isMastered
              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-[0_0_8px_rgba(245,158,11,0.3)]'
              : (isLiberated ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-slate-900 text-slate-500')
          }">
            ${isMastered ? '🏆 MASTER' : (isLiberated ? '✓ LIBERATED' : `${liberatedCount}/5 SAVED`)}
          </span>
        </div>
        <div class="mt-1 flex items-center justify-between text-[8px] font-orbitron">
          <span class="${isLiberated ? 'text-cosmic-mint font-bold' : 'text-slate-500'} truncate" title="${sec.bonus}">
            ${isLiberated ? '⚡ ' : '🔒 '}${sec.bonus}
          </span>
        </div>
      `;

      card.addEventListener('click', () => {
        audio.init();
        selectedSector = sec.id;
        const tabs = document.querySelectorAll('.sector-tab');
        tabs.forEach(t => {
          if (parseInt(t.getAttribute('data-sector'), 10) === selectedSector) {
            t.classList.add('active', 'bg-cosmic-cyan/20', 'text-cosmic-cyan', 'border-cosmic-cyan');
            t.classList.remove('bg-slate-900/50', 'text-slate-400', 'border-slate-800');
          } else {
            t.classList.remove('active', 'bg-cosmic-cyan/20', 'text-cosmic-cyan', 'border-cosmic-cyan');
            t.classList.add('bg-slate-900/50', 'text-slate-400', 'border-slate-800');
          }
        });
        const firstPlanet = PLANETS.find(p => p.sector === selectedSector);
        if (firstPlanet) selectedPlanetId = firstPlanet.id;
        drawStarMap();
      });

      bar.appendChild(card);
    }
  }

  function renderStarMapPlanets() {
    const grid = document.getElementById('planetsGrid');
    if (!grid) return;
    grid.innerHTML = '';

    const sectorPlanets = PLANETS.filter(p => p.sector === selectedSector);
    const unlocked = saveSystem.data.unlockedPlanet || 1;
    const activeIncursion = saveSystem.getActiveIncursion ? saveSystem.getActiveIncursion() : null;

    for (const p of sectorPlanets) {
      const isLocked = p.id > unlocked;
      const isSelected = p.id === selectedPlanetId;
      const stars = saveSystem.data.planetStars[p.id] || 0;
      const isIncursion = activeIncursion && activeIncursion.active && p.id === activeIncursion.planetId;

      const card = document.createElement('div');
      card.className = `glass-card p-3 rounded-2xl flex flex-col items-center text-center cursor-pointer transition border relative ${
        isIncursion
          ? (isSelected ? 'border-rose-500 ring-2 ring-rose-500/60 bg-rose-950/30' : 'border-rose-500/80 shadow-[0_0_15px_rgba(244,63,94,0.35)] bg-rose-950/20 hover:border-rose-400')
          : (isSelected ? 'border-cosmic-cyan ring-2 ring-cosmic-cyan/50 bg-cosmic-cyan/10' : (isLocked ? 'border-slate-800 opacity-60' : 'border-slate-700/60 hover:border-cosmic-cyan/60'))
      }`;

      const starIcons = isLocked
        ? '<span class="text-[10px] text-slate-500 font-orbitron">LOCKED</span>'
        : Array.from({ length: 3 }, (_, i) => ICON_SVG.star('w-3.5 h-3.5 ' + (i < stars ? 'text-cosmic-gold' : 'text-slate-700'), i < stars)).join('');

      card.innerHTML = `
        <div class="w-12 h-12 rounded-full mb-2 flex items-center justify-center text-xl shadow-lg relative" style="background: radial-gradient(circle at 35% 35%, ${p.color2}, ${p.color1} 70%, #030712); box-shadow: 0 0 12px ${isIncursion ? '#f43f5e' : p.atmo}66;">
          ${isLocked ? `<span class="bg-slate-900/90 p-1 rounded-full flex items-center justify-center">${ICON_SVG.lock('w-3 h-3 text-slate-300')}</span>` : ''}
          ${p.bossName ? `<span class="absolute -top-1 -right-1 flex items-center justify-center">${ICON_SVG.crown('w-3.5 h-3.5 text-cosmic-gold')}</span>` : ''}
          ${isIncursion ? `
            <!-- Pulsing Crimson Armada Siege Reticle + 3 Orbiting Warship Triangles -->
            <svg class="absolute -inset-2.5 w-[68px] h-[68px] pointer-events-none animate-spin" style="animation-duration: 9s;" viewBox="0 0 68 68">
              <circle cx="34" cy="34" r="30" fill="none" stroke="#f43f5e" stroke-width="1.5" stroke-dasharray="6 4" opacity="0.9" class="animate-pulse" />
              <line x1="34" y1="0" x2="34" y2="7" stroke="#ff1744" stroke-width="2" />
              <line x1="34" y1="61" x2="34" y2="68" stroke="#ff1744" stroke-width="2" />
              <line x1="0" y1="34" x2="7" y2="34" stroke="#ff1744" stroke-width="2" />
              <line x1="61" y1="34" x2="68" y2="34" stroke="#ff1744" stroke-width="2" />
              <polygon points="34,2 30,9 38,9" fill="#ff1744" />
              <polygon points="61,48 54,47 58,54" fill="#ff1744" />
              <polygon points="7,48 14,47 10,54" fill="#ff1744" />
            </svg>
          ` : ''}
        </div>
        <div class="text-xs font-black font-orbitron text-white truncate w-full">${p.name}</div>
        <div class="text-[9px] text-slate-400 truncate w-full">${p.title}</div>
        <div class="flex items-center gap-0.5 text-xs text-cosmic-gold mt-1.5">
          ${starIcons}
        </div>
        ${isIncursion ? `<div class="w-full text-center py-0.5 px-1 rounded-md text-[7px] font-orbitron font-black bg-rose-600/30 text-rose-300 border border-rose-500/50 animate-pulse mt-1">🚨 INCURSION ALERT: 2x SHARDS!</div>` : ''}
      `;

      if (!isLocked) {
        card.addEventListener('click', () => {
          audio.init();
          selectedPlanetId = p.id;
          renderStarMapPlanets();
          updateTacticalBriefing();
        });
      }

      grid.appendChild(card);
    }
  }

  function updateTacticalBriefing() {
    const planet = PLANETS.find(p => p.id === selectedPlanetId) || PLANETS[0];
    const stars = saveSystem.data.planetStars[planet.id] || 0;
    const activeIncursion = saveSystem.getActiveIncursion ? saveSystem.getActiveIncursion() : null;
    const isIncursion = activeIncursion && activeIncursion.active && planet.id === activeIncursion.planetId;

    document.getElementById('briefingSectorTag').textContent = `SECTOR ${'I'.repeat(planet.sector)}`;
    const starBriefing = Array.from({ length: 3 }, (_, i) => 
      ICON_SVG.star('w-4 h-4 ' + (i < stars ? 'text-cosmic-gold drop-shadow-[0_0_6px_#ffd700]' : 'text-slate-700'), i < stars)
    ).join('');
    document.getElementById('briefingStars').innerHTML = starBriefing;
    document.getElementById('briefingPlanetName').textContent = planet.name.toUpperCase();
    document.getElementById('briefingPlanetTitle').textContent = planet.title;
    document.getElementById('briefingWaves').textContent = `${planet.waves} Invasion Waves`;
    document.getElementById('briefingEnemies').textContent = `${planet.baseEnemies} Alien Invaders`;
    document.getElementById('briefingRings').textContent = planet.rings ? 'Yes (Encircled)' : 'None';
    
    const threatEl = document.getElementById('briefingBoss');
    if (threatEl) {
      if (isIncursion) {
        threatEl.innerHTML = '<span class="text-rose-400 font-bold animate-pulse">🚨 LIVING INCURSION: +1 ELITE / WAVE (2x ✦ SHARDS)</span>';
      } else {
        threatEl.textContent = planet.bossName ? `BOSS: ${planet.bossName}` : 'Standard Armada';
      }
    }

    const launchBtn = document.getElementById('btnLaunchMission');
    if (launchBtn) {
      if (isIncursion) {
        launchBtn.innerHTML = `
          <svg class="w-4 h-4 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4.5c1.62-1.63 5-2.5 5-2.5"/><path d="M12 15v5s3.03-.55 4.5-2c1.63-1.62 2.5-5 2.5-5"/></svg>
          <span>🚨 DEFEND INCURSION (2x ✦ SHARDS)</span>
        `;
        launchBtn.className = 'w-full py-3 rounded-xl font-orbitron font-black text-xs tracking-wider bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white shadow-[0_0_20px_rgba(244,63,94,0.4)] transition cursor-pointer flex items-center justify-center gap-2';
      } else {
        launchBtn.innerHTML = `
          <svg class="w-4 h-4 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4.5c1.62-1.63 5-2.5 5-2.5"/><path d="M12 15v5s3.03-.55 4.5-2c1.63-1.62 2.5-5 2.5-5"/></svg>
          <span>LAUNCH PLANETARY DEFENSE</span>
        `;
        launchBtn.className = 'w-full py-3 rounded-xl font-orbitron font-black text-xs tracking-wider bg-gradient-to-r from-cosmic-cyan to-blue-600 hover:from-cyan-300 hover:to-blue-500 text-slate-950 shadow-[0_0_15px_rgba(0,229,255,0.4)] transition cursor-pointer flex items-center justify-center gap-2';
      }
    }

    // Draw preview canvas
    const pCanvas = document.getElementById('briefingPlanetCanvas');
    if (pCanvas) {
      const pCtx = pCanvas.getContext('2d');
      pCtx.clearRect(0, 0, 70, 70);

      // Sphere
      const grad = pCtx.createRadialGradient(25, 25, 5, 35, 35, 32);
      grad.addColorStop(0, planet.color2);
      grad.addColorStop(0.7, planet.color1);
      grad.addColorStop(1, '#050814');

      pCtx.beginPath();
      pCtx.arc(35, 35, 26, 0, Math.PI * 2);
      pCtx.fillStyle = grad;
      pCtx.fill();

      // Atmospheric rim
      pCtx.strokeStyle = isIncursion ? '#f43f5e' : planet.atmo;
      pCtx.lineWidth = 2.5;
      pCtx.shadowColor = isIncursion ? '#f43f5e' : planet.atmo;
      pCtx.shadowBlur = 8;
      pCtx.stroke();
      pCtx.shadowBlur = 0;

      // Incursion Reticle overlay on briefing canvas
      if (isIncursion) {
        pCtx.save();
        pCtx.strokeStyle = '#f43f5e';
        pCtx.lineWidth = 1.5;
        pCtx.setLineDash([4, 4]);
        pCtx.beginPath();
        pCtx.arc(35, 35, 32, 0, Math.PI * 2);
        pCtx.stroke();
        pCtx.setLineDash([]);

        pCtx.strokeStyle = '#ff1744';
        pCtx.beginPath();
        pCtx.moveTo(35, 0); pCtx.lineTo(35, 6);
        pCtx.moveTo(35, 64); pCtx.lineTo(35, 70);
        pCtx.moveTo(0, 35); pCtx.lineTo(6, 35);
        pCtx.moveTo(64, 35); pCtx.lineTo(70, 35);
        pCtx.stroke();

        const angleStep = (Math.PI * 2) / 3;
        for (let w = 0; w < 3; w++) {
          const ang = w * angleStep - Math.PI / 2;
          const wx = 35 + Math.cos(ang) * 31;
          const wy = 35 + Math.sin(ang) * 31;
          pCtx.save();
          pCtx.translate(wx, wy);
          pCtx.rotate(ang + Math.PI / 2);
          pCtx.fillStyle = '#ff1744';
          pCtx.beginPath();
          pCtx.moveTo(0, -4);
          pCtx.lineTo(3, 4);
          pCtx.lineTo(-3, 4);
          pCtx.closePath();
          pCtx.fill();
          pCtx.restore();
        }
        pCtx.restore();
      }
    }
  }

  function openArmory() {
    document.getElementById('modalArmory').classList.remove('hidden');
    renderChassisDeck();
    renderShipyardDeck();
    renderWingmanDeck();
    renderTurretSkinDeck();
    renderRelicsDeck();
    renderArmoryGrid();
    updateArmoryAscensionBtn();
  }

  function renderShipyardDeck() {
    const container = document.getElementById('shipyardContainer');
    if (!container) return;
    container.innerHTML = '';

    const currentLoadout = saveSystem.getShipyardLoadout ? saveSystem.getShipyardLoadout() : { barrel: 'standard', reactor: 'balanced', shieldMod: 'hex' };
    const shards = saveSystem.data?.shards || 0;

    const SLOTS = [
      { key: 'barrel', label: 'SLOT A: BARREL ASSEMBLY', sub: 'Precision Bore, Gatling Array, Siege Fokus-Barrel' },
      { key: 'reactor', label: 'SLOT B: CORE REACTOR', sub: 'Harmonic Dynamo, Frenzy Overclock, Cryo-Capacitor' },
      { key: 'shieldMod', label: 'SLOT C: AEGIS SHIELD GEOMETRY', sub: 'Hex-Aegis, Phase-Parry Amp, Electrostatic Thorn' }
    ];

    for (const slot of SLOTS) {
      const partsObj = SHIPYARD_PARTS[slot.key] || {};
      const slotBox = document.createElement('div');
      slotBox.className = 'bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80';

      slotBox.innerHTML = `
        <div class="flex items-center justify-between pb-1.5 mb-2 border-b border-slate-800/70">
          <span class="text-[10px] font-orbitron font-bold text-cosmic-cyan">${slot.label}</span>
          <span class="text-[8px] font-orbitron text-slate-400">${slot.sub}</span>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-2" id="slotParts_${slot.key}"></div>
      `;

      const partsGrid = slotBox.querySelector(`#slotParts_${slot.key}`);
      for (const [partId, cfg] of Object.entries(partsObj)) {
        const isUnlocked = saveSystem.isShipyardPartUnlocked(slot.key, partId);
        const isEquipped = currentLoadout[slot.key] === partId;
        const canAfford = shards >= cfg.cost;

        const partCard = document.createElement('div');
        partCard.className = `glass-card p-2.5 rounded-xl flex flex-col justify-between border transition ${
          isEquipped
            ? 'border-cosmic-cyan ring-1 ring-cosmic-cyan/50 bg-cosmic-cyan/10'
            : (isUnlocked ? 'border-slate-700/60 hover:border-slate-500' : 'border-slate-800 opacity-75')
        }`;

        let actionBtn = '';
        if (isEquipped) {
          actionBtn = `
            <div class="w-full py-1 rounded-lg font-orbitron font-black text-[9px] tracking-wider text-center bg-cosmic-cyan/20 text-cosmic-cyan border border-cosmic-cyan/50">
              EQUIPPED
            </div>
          `;
        } else if (isUnlocked) {
          actionBtn = `
            <button class="btn-equip-shipyard w-full py-1 rounded-lg font-orbitron font-bold text-[9px] tracking-wider transition cursor-pointer bg-slate-800 hover:bg-cosmic-cyan hover:text-slate-950 text-white border border-slate-600 hover:border-cosmic-cyan" data-slot="${slot.key}" data-part="${partId}">
              EQUIP
            </button>
          `;
        } else {
          actionBtn = `
            <button class="btn-unlock-shipyard w-full py-1 rounded-lg font-orbitron font-bold text-[9px] tracking-wider transition cursor-pointer flex items-center justify-center gap-1 ${
              canAfford
                ? 'bg-gradient-to-r from-cosmic-gold to-amber-600 hover:from-amber-300 hover:to-amber-500 text-slate-950 font-black shadow-md'
                : 'bg-slate-900 text-slate-500 border border-slate-800 cursor-not-allowed'
            }" data-slot="${slot.key}" data-part="${partId}" ${canAfford ? '' : 'disabled'}>
              <span>UNLOCK [✦ ${cfg.cost}]</span>
            </button>
          `;
        }

        partCard.innerHTML = `
          <div>
            <div class="flex items-center justify-between mb-1.5">
              <div class="flex items-center gap-1.5">
                <span class="text-base">${cfg.icon}</span>
                <span class="font-orbitron font-bold text-xs text-white">${cfg.name}</span>
              </div>
              <span class="text-[8px] font-orbitron font-bold px-1.5 py-0.5 rounded ${
                isUnlocked ? 'bg-cosmic-mint/20 text-cosmic-mint border border-cosmic-mint/30' : 'bg-slate-800 text-slate-400'
              }">
                ${isUnlocked ? 'UNLOCKED' : `✦ ${cfg.cost}`}
              </span>
            </div>
            <p class="text-[9px] text-slate-300 leading-snug mb-2">${cfg.desc}</p>
          </div>
          ${actionBtn}
        `;

        partsGrid.appendChild(partCard);
      }

      container.appendChild(slotBox);
    }

    // Attach listeners
    container.querySelectorAll('.btn-equip-shipyard').forEach(btn => {
      btn.addEventListener('click', (e) => {
        audio.init();
        const slot = e.currentTarget.getAttribute('data-slot');
        const part = e.currentTarget.getAttribute('data-part');
        saveSystem.equipShipyardPart(slot, part);
        engine.applyUpgrades();
        renderShipyardDeck();
        const name = SHIPYARD_PARTS[slot]?.[part]?.name || part;
        engine.showToast(`EQUIPPED ${name.toUpperCase()}!`, '#00e5ff');
      });
    });

    container.querySelectorAll('.btn-unlock-shipyard').forEach(btn => {
      btn.addEventListener('click', (e) => {
        audio.init();
        const slot = e.currentTarget.getAttribute('data-slot');
        const part = e.currentTarget.getAttribute('data-part');
        const ok = saveSystem.unlockShipyardPart(slot, part);
        if (ok) {
          audio.playShardPickup();
          saveSystem.equipShipyardPart(slot, part);
          engine.applyUpgrades();
          renderShipyardDeck();
          renderArmoryGrid();
          const name = SHIPYARD_PARTS[slot]?.[part]?.name || part;
          engine.showToast(`UNLOCKED & EQUIPPED ${name.toUpperCase()}!`, '#ffd700');
        }
      });
    });
  }

  function renderChassisDeck() {
    const container = document.getElementById('chassisContainer');
    if (!container) return;
    container.innerHTML = '';

    const selectedId = saveSystem.getSelectedChassis();
    const totalStars = saveSystem.getTotalStars();
    const shards = saveSystem.data.shards;

    for (const [chassisId, cfg] of Object.entries(CHASSIS_CONFIG)) {
      const isUnlocked = saveSystem.isChassisUnlocked(chassisId);
      const isSelected = selectedId === chassisId;

      const card = document.createElement('div');
      card.className = `glass-card p-3 rounded-2xl flex flex-col justify-between border transition ${
        isSelected ? 'border-cosmic-cyan ring-2 ring-cosmic-cyan/50 bg-cosmic-cyan/10' : (isUnlocked ? 'border-slate-700/60 hover:border-slate-500' : 'border-slate-800 opacity-75')
      }`;

      let btnHtml = '';
      if (isSelected) {
        btnHtml = `
          <div class="w-full py-1.5 rounded-xl font-orbitron font-black text-[10px] tracking-wider text-center bg-cosmic-cyan/20 text-cosmic-cyan border border-cosmic-cyan/50">
            EQUIPPED LOADOUT
          </div>
        `;
      } else if (isUnlocked) {
        btnHtml = `
          <button class="btn-equip-chassis w-full py-1.5 rounded-xl font-orbitron font-bold text-[10px] tracking-wider transition cursor-pointer bg-slate-800 hover:bg-cosmic-cyan hover:text-slate-950 text-white border border-slate-600 hover:border-cosmic-cyan flex items-center justify-center gap-1.5" data-chassis="${chassisId}">
            EQUIP CHASSIS
          </button>
        `;
      } else {
        const canAfford = shards >= cfg.costShards;
        btnHtml = `
          <button class="btn-unlock-chassis w-full py-1.5 rounded-xl font-orbitron font-bold text-[10px] tracking-wider transition cursor-pointer flex items-center justify-center gap-1.5 ${
            canAfford ? 'bg-gradient-to-r from-cosmic-gold to-amber-600 hover:from-amber-300 hover:to-amber-500 text-slate-950 font-black shadow-md' : 'bg-slate-900 text-slate-500 border border-slate-800 cursor-not-allowed'
          }" data-chassis="${chassisId}" ${canAfford ? '' : 'disabled'}>
            <span class="flex items-center gap-1">UNLOCK [${ICON_SVG.shard('w-3 h-3 ' + (canAfford ? 'text-slate-950' : 'text-cosmic-gold'))} ${cfg.costShards}]</span>
          </button>
        `;
      }

      card.innerHTML = `
        <div>
          <div class="flex items-center justify-between mb-2">
            <div class="flex items-center gap-2">
              <div class="w-9 h-9 rounded-xl flex items-center justify-center bg-slate-950/80 border border-slate-700/60 shrink-0">
                ${ICON_SVG.chassisSvg(chassisId)}
              </div>
              <div>
                <div class="font-orbitron font-black text-xs text-white">${cfg.name}</div>
                <div class="text-[9px] font-orbitron font-bold" style="color: ${cfg.color}">${cfg.role}</div>
              </div>
            </div>
            <span class="text-[9px] font-orbitron font-bold px-1.5 py-0.5 rounded ${
              isUnlocked ? 'bg-cosmic-mint/20 text-cosmic-mint border border-cosmic-mint/30' : 'bg-slate-800 text-slate-400'
            }">
              ${isUnlocked ? 'UNLOCKED' : (cfg.reqStars ? `${cfg.reqStars} ★ REQ` : 'LOCKED')}
            </span>
          </div>
          <p class="text-[10px] text-slate-300 leading-snug mb-2">${cfg.desc}</p>
          <div class="bg-slate-950/50 p-1.5 rounded-xl border border-slate-800/80 text-[9px] font-orbitron text-cosmic-gold mb-3">
            PERK: <span class="text-slate-300">${cfg.perkDesc}</span>
          </div>
        </div>
        ${btnHtml}
      `;

      container.appendChild(card);
    }

    // Equip listeners
    container.querySelectorAll('.btn-equip-chassis').forEach(btn => {
      btn.addEventListener('click', (e) => {
        audio.init();
        const id = e.currentTarget.getAttribute('data-chassis');
        saveSystem.selectChassis(id);
        engine.applyUpgrades();
        renderChassisDeck();
        engine.showToast(`EQUIPPED ${CHASSIS_CONFIG[id]?.name.toUpperCase()}!`, '#00e5ff');
      });
    });

    // Unlock listeners
    container.querySelectorAll('.btn-unlock-chassis').forEach(btn => {
      btn.addEventListener('click', (e) => {
        audio.init();
        const id = e.currentTarget.getAttribute('data-chassis');
        const unlocked = saveSystem.unlockChassis(id);
        if (unlocked) {
          audio.playShardPickup();
          engine.applyUpgrades();
          renderChassisDeck();
          renderArmoryGrid();
          engine.showToast(`UNLOCKED ${CHASSIS_CONFIG[id]?.name.toUpperCase()}!`, '#ffd700');
        }
      });
    });
  }

  function renderWingmanDeck() {
    const container = document.getElementById('wingmanDoctrinesContainer');
    const statusEl = document.getElementById('wingmanUnlockStatus');
    if (!container) return;
    container.innerHTML = '';

    const isUnlocked = saveSystem.isWingmanUnlocked();
    const selectedDoctrine = saveSystem.getSelectedWingmanDoctrine();
    const shards = saveSystem.data.shards;
    const canAffordUnlock = shards >= WINGMAN_CONFIG.unlockCostShards;

    if (statusEl) {
      if (isUnlocked) {
        statusEl.innerHTML = `<span class="text-cosmic-mint font-bold">✓ WING-01 OPERATIONAL</span>`;
      } else {
        statusEl.innerHTML = `<span class="text-slate-400">REQ: SATELLITES LV.2 OR ✦ 200</span>`;
      }
    }

    for (const [id, cfg] of Object.entries(WINGMAN_CONFIG.doctrines)) {
      const isSelected = selectedDoctrine === id;
      const card = document.createElement('div');
      card.className = `glass-card p-3 rounded-2xl flex flex-col justify-between border transition ${
        isUnlocked && isSelected ? 'border-cosmic-mint ring-2 ring-cosmic-mint/50 bg-cosmic-mint/10' : (isUnlocked ? 'border-slate-700/60 hover:border-slate-500' : 'border-slate-800 opacity-75')
      }`;

      let btnHtml = '';
      if (!isUnlocked) {
        btnHtml = `
          <button class="btn-unlock-wingman w-full py-1.5 rounded-xl font-orbitron font-bold text-[10px] tracking-wider transition cursor-pointer flex items-center justify-center gap-1.5 ${
            canAffordUnlock ? 'bg-gradient-to-r from-cosmic-mint to-teal-500 hover:from-emerald-300 hover:to-teal-400 text-slate-950 font-black shadow-md' : 'bg-slate-900 text-slate-500 border border-slate-800 cursor-not-allowed'
          }" ${canAffordUnlock ? '' : 'disabled'}>
            <span class="flex items-center gap-1">UNLOCK WING-01 [${ICON_SVG.shard('w-3 h-3 ' + (canAffordUnlock ? 'text-slate-950' : 'text-cosmic-gold'))} ${WINGMAN_CONFIG.unlockCostShards}]</span>
          </button>
        `;
      } else if (isSelected) {
        btnHtml = `
          <div class="w-full py-1.5 rounded-xl font-orbitron font-black text-[10px] tracking-wider text-center bg-cosmic-mint/20 text-cosmic-mint border border-cosmic-mint/50">
            ACTIVE DOCTRINE
          </div>
        `;
      } else {
        btnHtml = `
          <button class="btn-equip-doctrine w-full py-1.5 rounded-xl font-orbitron font-bold text-[10px] tracking-wider transition cursor-pointer bg-slate-800 hover:bg-cosmic-mint hover:text-slate-950 text-white border border-slate-600 hover:border-cosmic-mint flex items-center justify-center gap-1.5" data-doctrine="${id}">
            ENGAGE DOCTRINE
          </button>
        `;
      }

      card.innerHTML = `
        <div>
          <div class="flex items-center justify-between mb-1.5">
            <div class="flex items-center gap-2">
              <span class="text-xl p-1 rounded-lg bg-slate-950/80 border border-slate-800 shrink-0">${cfg.icon}</span>
              <div>
                <div class="font-orbitron font-black text-xs text-white">${cfg.name}</div>
                <div class="text-[9px] font-orbitron font-bold" style="color: ${cfg.color}">${cfg.role}</div>
              </div>
            </div>
            <span class="text-[9px] font-orbitron font-bold px-1.5 py-0.5 rounded ${
              isUnlocked ? 'bg-cosmic-mint/20 text-cosmic-mint border border-cosmic-mint/30' : 'bg-slate-800 text-slate-400'
            }">
              ${isUnlocked ? (isSelected ? 'ACTIVE' : 'READY') : 'LOCKED'}
            </span>
          </div>
          <p class="text-[10px] text-slate-300 leading-snug mb-2">${cfg.desc}</p>
          <div class="bg-slate-950/50 p-1.5 rounded-xl border border-slate-800/80 text-[9px] font-orbitron text-cosmic-gold mb-2.5">
            PERK: <span class="text-slate-300">${cfg.perkDesc}</span>
          </div>
        </div>
        ${btnHtml}
      `;

      container.appendChild(card);
    }

    container.querySelectorAll('.btn-equip-doctrine').forEach(btn => {
      btn.addEventListener('click', (e) => {
        audio.init();
        const id = e.currentTarget.getAttribute('data-doctrine');
        saveSystem.selectWingmanDoctrine(id);
        if (engine.wingman) engine.wingman.setDoctrine(id);
        renderWingmanDeck();
        engine.showToast(`AI WINGMAN: ${WINGMAN_CONFIG.doctrines[id]?.name.toUpperCase()} ENGAGED!`, '#00e676');
      });
    });

    container.querySelectorAll('.btn-unlock-wingman').forEach(btn => {
      btn.addEventListener('click', () => {
        audio.init();
        const success = saveSystem.unlockWingman();
        if (success) {
          audio.playShardPickup();
          engine.applyUpgrades();
          renderWingmanDeck();
          renderArmoryGrid();
          engine.showToast('AI WINGMAN STARFIGHTER (WING-01) UNLOCKED!', '#00e676');
        }
      });
    });
  }

  function renderTurretSkinDeck() {
    const container = document.getElementById('turretSkinsContainer');
    if (!container) return;
    container.innerHTML = '';

    const selectedSkin = saveSystem.getSelectedTurretSkin();

    for (const [id, skin] of Object.entries(TURRET_SKINS)) {
      const isUnlocked = saveSystem.isTurretSkinUnlocked(id);
      const isSelected = selectedSkin === id;

      const card = document.createElement('div');
      card.className = `glass-card p-2.5 rounded-2xl flex flex-col justify-between border transition ${
        isSelected ? 'border-cosmic-gold ring-2 ring-cosmic-gold/50 bg-cosmic-gold/10' : (isUnlocked ? 'border-slate-700/60 hover:border-slate-500' : 'border-slate-800 opacity-70')
      }`;

      let btnHtml = '';
      if (isSelected) {
        btnHtml = `
          <div class="w-full py-1 rounded-lg font-orbitron font-black text-[9px] tracking-wider text-center bg-cosmic-gold/20 text-cosmic-gold border border-cosmic-gold/50">
            APPLIED
          </div>
        `;
      } else if (isUnlocked) {
        btnHtml = `
          <button class="btn-equip-skin w-full py-1 rounded-lg font-orbitron font-bold text-[9px] tracking-wider transition cursor-pointer bg-slate-800 hover:bg-cosmic-gold hover:text-slate-950 text-white border border-slate-600 hover:border-cosmic-gold flex items-center justify-center gap-1" data-skin="${id}">
            EQUIP SKIN
          </button>
        `;
      } else {
        const reqText = skin.reqAscension ? `ASCENSION TIER ${skin.reqAscension}` : `${skin.reqStars} ★ REQUIRED`;
        btnHtml = `
          <div class="w-full py-1 rounded-lg font-orbitron font-bold text-[8px] tracking-wider text-center bg-slate-900 text-slate-500 border border-slate-800">
            ${reqText}
          </div>
        `;
      }

      card.innerHTML = `
        <div>
          <div class="flex items-center gap-2 mb-1.5">
            <div class="w-6 h-6 rounded-full border shadow-sm shrink-0" style="background: radial-gradient(circle, ${skin.primaryColor}, ${skin.accentColor}); border-color: ${skin.glowColor}; box-shadow: 0 0 8px ${skin.glowColor};"></div>
            <div class="truncate">
              <div class="font-orbitron font-black text-xs text-white truncate">${skin.name}</div>
              <div class="text-[8px] text-slate-400 font-orbitron">${isUnlocked ? 'UNLOCKED' : (skin.reqAscension ? `ASCENSION I+` : `${skin.reqStars} ★`)}</div>
            </div>
          </div>
          <p class="text-[9px] text-slate-300 leading-snug mb-2 line-clamp-2">${skin.desc}</p>
        </div>
        ${btnHtml}
      `;

      container.appendChild(card);
    }

    container.querySelectorAll('.btn-equip-skin').forEach(btn => {
      btn.addEventListener('click', (e) => {
        audio.init();
        const id = e.currentTarget.getAttribute('data-skin');
        saveSystem.selectTurretSkin(id);
        engine.turret.setSkin(id);
        renderTurretSkinDeck();
        engine.showToast(`TURRET HULL SKIN: ${TURRET_SKINS[id]?.name.toUpperCase()} EQUIPPED!`, TURRET_SKINS[id]?.primaryColor || '#ffd700');
      });
    });
  }

  function renderRelicsDeck() {
    const slotsContainer = document.getElementById('activeRelicSlots');
    const gridContainer = document.getElementById('relicsGrid');
    const countEl = document.getElementById('relicsEquippedCount');
    if (!slotsContainer || !gridContainer) return;

    const equipped = saveSystem.getEquippedRelics();
    if (countEl) {
      countEl.textContent = `${equipped.length} / 3 EQUIPPED`;
    }

    // 1. Render 3 Active Slots
    slotsContainer.innerHTML = '';
    for (let i = 0; i < 3; i++) {
      const relicId = equipped[i];
      const relic = relicId ? COSMIC_RELICS[relicId] : null;
      const slotEl = document.createElement('div');
      slotEl.className = `p-2 rounded-xl flex items-center gap-2 border transition ${
        relic ? 'glass-card border-amber-500/60 bg-amber-500/10 cursor-pointer hover:border-amber-400' : 'border-dashed border-slate-800 bg-slate-950/40'
      }`;

      if (relic) {
        slotEl.innerHTML = `
          <div class="text-lg shrink-0">${relic.icon}</div>
          <div class="flex-1 min-w-0">
            <div class="text-[10px] font-orbitron font-black text-amber-300 truncate">${relic.name}</div>
            <div class="text-[8px] text-slate-400 truncate">CLICK TO UNEQUIP</div>
          </div>
        `;
        slotEl.addEventListener('click', () => {
          audio.init();
          saveSystem.unequipRelic(relicId);
          engine.applyUpgrades();
          renderRelicsDeck();
        });
      } else {
        slotEl.innerHTML = `
          <div class="w-full text-center py-1">
            <div class="text-[9px] font-orbitron text-slate-600 font-bold">SLOT ${i + 1}</div>
            <div class="text-[8px] text-slate-600">EMPTY</div>
          </div>
        `;
      }
      slotsContainer.appendChild(slotEl);
    }

    // 2. Render 8 Collectible Relics Grid
    gridContainer.innerHTML = '';
    for (const [id, relic] of Object.entries(COSMIC_RELICS)) {
      const isUnlocked = saveSystem.isRelicUnlocked(id);
      const isEquipped = saveSystem.isRelicEquipped(id);

      const card = document.createElement('div');
      card.className = `glass-card p-2.5 rounded-xl flex flex-col justify-between border transition ${
        isEquipped
          ? 'border-amber-400 ring-2 ring-amber-400/40 bg-amber-400/15 cursor-pointer'
          : (isUnlocked
            ? 'border-slate-700/60 hover:border-amber-500/60 bg-slate-900/40 cursor-pointer'
            : 'border-slate-800/80 bg-slate-950/60 opacity-60')
      }`;

      card.innerHTML = `
        <div>
          <div class="flex items-center justify-between mb-1.5">
            <div class="flex items-center gap-1.5">
              <span class="text-base">${isUnlocked ? relic.icon : '🔒'}</span>
              <span class="text-[10px] font-orbitron font-black ${isUnlocked ? 'text-white' : 'text-slate-500'} truncate">${relic.name}</span>
            </div>
            <span class="text-[8px] font-orbitron font-bold px-1.5 py-0.5 rounded ${
              isEquipped ? 'bg-amber-400/20 text-amber-300 border border-amber-400/50' : (isUnlocked ? 'bg-cosmic-mint/20 text-cosmic-mint' : 'bg-slate-800 text-slate-500')
            }">
              ${isEquipped ? 'EQUIPPED' : (isUnlocked ? 'READY' : 'LOCKED')}
            </span>
          </div>
          <p class="text-[9px] text-slate-300 leading-tight mb-2">${isUnlocked ? relic.desc : 'Defeat Sector Bosses or Anomaly to unlock'}</p>
        </div>
        <div class="text-[8px] font-orbitron font-bold text-center py-1 rounded-lg ${
          isEquipped ? 'bg-amber-500/20 text-amber-300' : (isUnlocked ? 'bg-slate-800 hover:bg-amber-500 hover:text-slate-950 text-slate-300' : 'bg-slate-900 text-slate-600')
        }">
          ${isEquipped ? '✕ CLICK TO UNEQUIP' : (isUnlocked ? '✓ EQUIP (MAX 3)' : 'DEFEAT BOSS')}
        </div>
      `;

      if (isUnlocked) {
        card.addEventListener('click', () => {
          audio.init();
          if (isEquipped) {
            saveSystem.unequipRelic(id);
            engine.showToast(`UNEQUIPPED ${relic.name.toUpperCase()}`, '#ffd700');
          } else {
            const success = saveSystem.equipRelic(id);
            if (success) {
              engine.showToast(`EQUIPPED ${relic.name.toUpperCase()}!`, '#00e676');
            } else {
              engine.showToast('MAX 3 RELICS EQUIPPED! Unequip one first.', '#ff3366');
            }
          }
          engine.applyUpgrades();
          renderRelicsDeck();
        });
      }

      gridContainer.appendChild(card);
    }
  }

  function updateArmoryAscensionBtn() {
    const btn = document.getElementById('btnArmoryAscension');
    const label = document.getElementById('armoryAscensionText');
    if (!btn || !label) return;
    const tier = saveSystem.data.ascensionTier || 0;
    const canAscend = saveSystem.canAscend();
    label.textContent = tier > 0 ? `HYPERDRIVE ASCENSION (TIER ${tier})` : 'HYPERDRIVE ASCENSION';
    if (canAscend) {
      btn.classList.add('border-purple-400', 'text-purple-300', 'animate-pulse');
    } else {
      btn.classList.remove('border-purple-400', 'text-purple-300', 'animate-pulse');
    }
  }

  function renderArmoryGrid() {
    const grid = document.getElementById('armoryGrid');
    if (!grid) return;
    grid.innerHTML = '';

    document.getElementById('armoryShards').textContent = saveSystem.data.shards.toLocaleString();

    for (const [techId, cfg] of Object.entries(ARMORY_CONFIG)) {
      const lvl = saveSystem.data.upgrades[techId] || 0;
      const isMaxed = lvl >= cfg.maxLevel;
      const cost = saveSystem.getUpgradeCost(techId);
      const canAfford = !isMaxed && saveSystem.data.shards >= cost;

      const card = document.createElement('div');
      card.className = 'glass-card p-3.5 rounded-2xl flex flex-col justify-between border border-slate-700/60';

      card.innerHTML = `
        <div>
          <div class="flex items-center justify-between mb-1.5">
            <span class="flex items-center gap-2 font-orbitron font-bold text-xs text-white">
              <span class="text-base">${cfg.icon}</span>
              <span>${cfg.name}</span>
            </span>
            <span class="text-[10px] font-orbitron font-extrabold px-2 py-0.5 rounded-md ${
              isMaxed ? 'bg-cosmic-mint/20 text-cosmic-mint border border-cosmic-mint/30' : 'bg-cosmic-gold/20 text-cosmic-gold border border-cosmic-gold/30'
            }">
              ${isMaxed ? 'MAX LEVEL' : `Lv.${lvl} / ${cfg.maxLevel}`}
            </span>
          </div>
          <p class="text-[11px] text-slate-300 leading-snug mb-3">${cfg.desc}</p>
        </div>

        <button class="btn-upgrade-tech w-full py-2 rounded-xl font-orbitron font-bold text-xs transition cursor-pointer flex items-center justify-center gap-1.5 ${
          isMaxed ? 'bg-slate-800 text-slate-500 cursor-not-allowed' : (canAfford ? 'bg-gradient-to-r from-cosmic-gold to-amber-600 hover:from-amber-300 hover:to-amber-500 text-slate-950 font-black shadow-md' : 'bg-slate-800/80 text-slate-400 border border-slate-700')
        }" data-tech="${techId}" ${isMaxed || !canAfford ? 'disabled' : ''}>
          ${isMaxed ? 'TECH MAXED' : `<span class="flex items-center gap-1">UPGRADE [${ICON_SVG.shard('w-3.5 h-3.5 ' + (canAfford ? 'text-slate-950' : 'text-cosmic-gold'))} ${cost}]</span>`}
        </button>
      `;

      grid.appendChild(card);
    }

    // Attach upgrade listeners
    const upgradeButtons = grid.querySelectorAll('.btn-upgrade-tech');
    upgradeButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
        audio.init();
        const techId = e.currentTarget.getAttribute('data-tech');
        const success = saveSystem.upgradeTech(techId);
        if (success) {
          audio.playShardPickup();
          renderArmoryGrid();
          renderChassisDeck();
          renderShipyardDeck();
          renderWingmanDeck();
          renderTurretSkinDeck();
          updateArmoryAscensionBtn();
          engine.applyUpgrades();
        }
      });
    });
  }

  function openCodex() {
    document.getElementById('modalCodex').classList.remove('hidden');
    renderCodexList();
  }

  function renderCodexList() {
    const list = document.getElementById('codexList');
    if (!list) return;

    let hallContainer = document.getElementById('hallOfChampionsContainer');
    let dossiersContainer = document.getElementById('alienDossiersContainer');

    if (!hallContainer || !dossiersContainer) {
      list.innerHTML = `
        <div id="hallOfChampionsContainer" class="glass-panel p-3.5 rounded-2xl border border-cosmic-gold/40 mb-3"></div>
        <div id="alienDossiersContainer" class="space-y-3"></div>
      `;
      hallContainer = document.getElementById('hallOfChampionsContainer');
      dossiersContainer = document.getElementById('alienDossiersContainer');
    }

    renderHallOfChampions(hallContainer);

    dossiersContainer.innerHTML = '';

    // 10 Alien Dossiers
    for (const [key, alien] of Object.entries(ALIEN_CLASSES)) {
      const card = document.createElement('div');
      card.className = 'glass-card p-3.5 rounded-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-3 border border-slate-700/50 hover:border-cosmic-cyan/40 transition';

      card.innerHTML = `
        <div class="flex items-center gap-3.5">
          <div class="shrink-0 flex items-center justify-center p-1.5 rounded-xl bg-slate-950/70 border" style="border-color: ${alien.color}44;">
            ${ICON_SVG.shipSvg(key)}
          </div>
          <div>
            <div class="flex flex-wrap items-center gap-2">
              <h4 class="font-orbitron font-bold text-sm text-white">${alien.name}</h4>
              <span class="text-[9px] font-orbitron px-2 py-0.5 rounded-full font-bold" style="background: ${alien.color}22; color: ${alien.color}; border: 1px solid ${alien.color}44;">
                ${alien.role}
              </span>
            </div>
            <p class="text-[11px] text-slate-300 mt-1 max-w-md">${alien.behaviorDesc}</p>
            <div class="flex flex-wrap items-center gap-2 mt-2">
              <span class="text-[10px] font-orbitron px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300">
                HP: <strong class="text-white">${alien.hp}</strong>
              </span>
              <span class="text-[10px] font-orbitron px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300">
                SPEED: <strong class="text-white">${alien.speed} px/s</strong>
              </span>
              <span class="text-[10px] font-orbitron px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300">
                NOVA: <strong class="text-cosmic-gold">${alien.novaRadius}px</strong>
              </span>
              <span class="text-[10px] font-orbitron px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300">
                VAL: <strong class="text-cosmic-cyan">${alien.score} pts</strong>
              </span>
            </div>
          </div>
        </div>

        <div class="text-left md:text-right shrink-0 font-orbitron text-[10px] bg-slate-950/40 p-2.5 rounded-xl border border-slate-800/80 min-w-[170px]">
          <div class="text-slate-400 font-semibold mb-0.5">DEATH PAYLOAD:</div>
          <div class="font-bold text-xs" style="color: ${alien.color};">${alien.deathPayload}</div>
        </div>
      `;

      dossiersContainer.appendChild(card);
    }

    // Trophies section inside Codex
    const trophHeader = document.createElement('h3');
    trophHeader.className = 'font-orbitron font-black text-sm text-cosmic-gold mt-4 mb-2 flex items-center gap-2';
    trophHeader.innerHTML = `${ICON_SVG.trophy('w-4 h-4 text-cosmic-gold')} <span>GUARDIAN TROPHIES SHOWCASE</span>`;
    dossiersContainer.appendChild(trophHeader);

    for (const t of TROPHIES) {
      const isUnlocked = !!saveSystem.data.trophies[t.id];
      const card = document.createElement('div');
      card.className = `glass-card p-3 rounded-2xl flex items-center justify-between gap-3 border ${
        isUnlocked ? 'border-cosmic-gold/50 bg-cosmic-gold/10' : 'border-slate-800 opacity-60'
      }`;

      card.innerHTML = `
        <div class="flex items-center gap-3">
          <span class="text-2xl">${t.icon}</span>
          <div>
            <div class="font-orbitron font-bold text-xs ${isUnlocked ? 'text-cosmic-gold' : 'text-slate-400'}">${t.name}</div>
            <div class="text-[10px] text-slate-400">${t.desc}</div>
          </div>
        </div>
        <div class="font-orbitron text-xs font-bold ${isUnlocked ? 'text-cosmic-mint' : 'text-slate-500'}">
          ${isUnlocked ? `<span class="flex items-center gap-1 font-bold">UNLOCKED (+${t.reward} ${ICON_SVG.shard('w-3.5 h-3.5 text-cosmic-gold')})</span>` : 'LOCKED'}
        </div>
      `;
      dossiersContainer.appendChild(card);
    }
  }

  function renderHallOfChampions(container) {
    if (!container) return;
    container.innerHTML = '';

    const runs = saveSystem.getRunHistory ? saveSystem.getRunHistory() : [];

    const header = document.createElement('div');
    header.className = 'flex items-center justify-between pb-2 mb-2 border-b border-slate-800';
    header.innerHTML = `
      <div class="flex items-center gap-2">
        <span class="text-xl">🏆</span>
        <div>
          <h3 class="font-orbitron font-black text-sm text-cosmic-gold tracking-wide">🏆 HALL OF CHAMPIONS (TOP 10 COMMANDER RUNS)</h3>
          <p class="text-[9px] text-slate-400">Classified orbital telemetry & high-score battle records</p>
        </div>
      </div>
      <span class="text-[9px] font-orbitron font-bold text-cosmic-cyan px-2 py-0.5 rounded bg-cosmic-cyan/10 border border-cosmic-cyan/30">${runs.length} / 10 LOGGED</span>
    `;
    container.appendChild(header);

    if (runs.length === 0) {
      const emptyBox = document.createElement('div');
      emptyBox.className = 'text-center py-6 text-slate-400 text-xs font-orbitron';
      emptyBox.textContent = 'No combat records logged yet, Commander. Defend celestial worlds or enter Titan Protocol to claim your place in the Hall of Champions!';
      container.appendChild(emptyBox);
      return;
    }

    const tableWrap = document.createElement('div');
    tableWrap.className = 'overflow-x-auto';

    const table = document.createElement('table');
    table.className = 'w-full text-left text-xs font-orbitron';
    table.innerHTML = `
      <thead>
        <tr class="text-[9px] text-slate-400 border-b border-slate-800/80">
          <th class="py-1.5 px-2">RANK</th>
          <th class="py-1.5 px-2">DATE & MODE</th>
          <th class="py-1.5 px-2">PLANET</th>
          <th class="py-1.5 px-2">FINAL SCORE</th>
          <th class="py-1.5 px-2">COMBO</th>
          <th class="py-1.5 px-2">WAVE</th>
          <th class="py-1.5 px-2">CHASSIS & SYNERGIES</th>
          <th class="py-1.5 px-2 text-right">ACTION</th>
        </tr>
      </thead>
      <tbody id="hallOfChampionsBody" class="divide-y divide-slate-800/50"></tbody>
    `;

    const tbody = table.querySelector('#hallOfChampionsBody');
    runs.forEach((run, idx) => {
      const row = document.createElement('tr');
      row.className = 'hover:bg-slate-900/40 transition';

      let rankMedal = `#${idx + 1}`;
      if (idx === 0) rankMedal = '🥇 #1';
      else if (idx === 1) rankMedal = '🥈 #2';
      else if (idx === 2) rankMedal = '🥉 #3';

      let dateStr = 'Recent';
      if (run.date) {
        try {
          const d = new Date(run.date);
          dateStr = d.toLocaleDateString(undefined, { month: 'numeric', day: 'numeric', year: '2-digit' });
        } catch { dateStr = 'Recent'; }
      }

      let modeBadge = 'Campaign';
      let modeClass = 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40';
      const mUpper = (run.mode || '').toUpperCase();
      if (mUpper === 'TITAN' || mUpper === 'TITAN PROTOCOL') {
        modeBadge = 'Titan Protocol';
        modeClass = 'bg-amber-500/20 text-amber-300 border-amber-500/40';
      } else if (mUpper === 'DAILY' || mUpper === 'DAILY ANOMALY') {
        modeBadge = 'Daily Anomaly';
        modeClass = 'bg-orange-500/20 text-orange-300 border-orange-500/40';
      } else if (mUpper === 'ENDLESS') {
        modeBadge = 'Endless';
        modeClass = 'bg-purple-500/20 text-purple-300 border-purple-500/40';
      } else if (mUpper === 'INCURSION') {
        modeBadge = 'Incursion';
        modeClass = 'bg-rose-500/20 text-rose-300 border-rose-500/40';
      }

      const chassisName = CHASSIS_CONFIG[run.chassis]?.name || run.chassis || 'Striker';
      let synBadges = '';
      if (Array.isArray(run.synergies) && run.synergies.length > 0) {
        synBadges = `<span class="text-[8px] px-1 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">+${run.synergies.length} Syn</span>`;
      }

      row.innerHTML = `
        <td class="py-2 px-2 font-black ${idx === 0 ? 'text-cosmic-gold' : (idx < 3 ? 'text-slate-200' : 'text-slate-400')}">${rankMedal}</td>
        <td class="py-2 px-2">
          <div class="flex items-center gap-1.5 flex-wrap">
            <span class="text-[9px] px-1.5 py-0.5 rounded-full font-bold border ${modeClass}">${modeBadge}</span>
            <span class="text-[9px] text-slate-400 font-mono">${dateStr}</span>
          </div>
        </td>
        <td class="py-2 px-2 font-bold text-white">${run.planetName || 'Aerilon'}</td>
        <td class="py-2 px-2 font-black text-cosmic-cyan">${(run.score || 0).toLocaleString()}</td>
        <td class="py-2 px-2 font-bold text-cosmic-magenta">x${run.maxCombo || 1}</td>
        <td class="py-2 px-2 text-slate-300">W${run.waveReached || 1}</td>
        <td class="py-2 px-2">
          <div class="flex items-center gap-1.5">
            <span class="text-[10px] text-slate-300">${chassisName}</span>
            ${synBadges}
          </div>
        </td>
        <td class="py-2 px-2 text-right">
          <button class="btn-view-historical-card px-2.5 py-1 rounded-lg font-orbitron font-bold text-[9px] bg-amber-500/20 hover:bg-amber-500/40 text-amber-300 border border-amber-500/40 transition cursor-pointer inline-flex items-center gap-1 shadow-sm" data-idx="${idx}">
            📸 View Card
          </button>
        </td>
      `;

      tbody.appendChild(row);
    });

    tableWrap.appendChild(table);
    container.appendChild(tableWrap);

    // View card listener
    container.querySelectorAll('.btn-view-historical-card').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const idx = parseInt(e.currentTarget.getAttribute('data-idx'), 10);
        const selectedRun = runs[idx];
        if (selectedRun) {
          openHistoricalBattleCard(selectedRun);
        }
      });
    });
  }

  // ==================== TACTICAL SETTINGS MODAL ====================
  function openSettingsModal() {
    audio.init();
    syncSettingsUI();
    document.getElementById('modalSettings')?.classList.remove('hidden');
  }

  function syncSettingsUI() {
    const s = saveSystem.getSettings();

    // Screen shake
    document.querySelectorAll('.btn-setting-shake').forEach(btn => {
      const val = parseInt(btn.getAttribute('data-val'), 10);
      const active = (s.screenShake === val);
      btn.className = `btn-setting-shake px-2.5 py-1 rounded-lg text-[10px] font-orbitron font-bold border transition cursor-pointer ${
        active ? 'bg-cosmic-cyan text-slate-950 border-cosmic-cyan shadow-[0_0_10px_rgba(0,229,255,0.4)]' : 'bg-slate-900 text-slate-400 border-slate-700 hover:border-slate-500'
      }`;
    });

    // Particle density
    document.querySelectorAll('.btn-setting-part').forEach(btn => {
      const val = btn.getAttribute('data-val');
      const active = (s.particleDensity === val);
      btn.className = `btn-setting-part px-3 py-1 rounded-lg text-[10px] font-orbitron font-bold border transition cursor-pointer ${
        active ? 'bg-cosmic-cyan text-slate-950 border-cosmic-cyan shadow-[0_0_10px_rgba(0,229,255,0.4)]' : 'bg-slate-900 text-slate-400 border-slate-700 hover:border-slate-500'
      }`;
    });

    // Threat rings
    document.querySelectorAll('.btn-setting-threat').forEach(btn => {
      const val = (btn.getAttribute('data-val') === 'true');
      const active = (s.threatRings === val);
      btn.className = `btn-setting-threat px-3 py-1 rounded-lg text-[10px] font-orbitron font-bold border transition cursor-pointer ${
        active ? 'bg-cosmic-cyan text-slate-950 border-cosmic-cyan shadow-[0_0_10px_rgba(0,229,255,0.4)]' : 'bg-slate-900 text-slate-400 border-slate-700 hover:border-slate-500'
      }`;
    });

    // Floating text
    document.querySelectorAll('.btn-setting-text').forEach(btn => {
      const val = btn.getAttribute('data-val');
      const active = (s.floatingText === val);
      btn.className = `btn-setting-text px-2.5 py-1 rounded-lg text-[10px] font-orbitron font-bold border transition cursor-pointer ${
        active ? 'bg-cosmic-cyan text-slate-950 border-cosmic-cyan shadow-[0_0_10px_rgba(0,229,255,0.4)]' : 'bg-slate-900 text-slate-400 border-slate-700 hover:border-slate-500'
      }`;
    });

    // Art Style (v3.1)
    const currentStyle = s.artStyle || 'astral';
    document.querySelectorAll('.btn-setting-style').forEach(btn => {
      const val = btn.getAttribute('data-val');
      const active = (currentStyle === val);
      btn.className = `btn-setting-style px-2.5 py-1 rounded-lg text-[10px] font-orbitron font-bold border transition cursor-pointer ${
        active ? 'bg-cosmic-cyan text-slate-950 border-cosmic-cyan shadow-[0_0_10px_rgba(0,229,255,0.4)]' : 'bg-slate-900 text-slate-400 border-slate-700 hover:border-slate-500'
      }`;
    });
    updateArtStyleButton(currentStyle);

    updateGamepadBadge();
  }

  function updateGamepadBadge() {
    const badge = document.getElementById('gamepadStatusBadge');
    if (!badge) return;
    const gamepads = (typeof navigator !== 'undefined' && navigator.getGamepads) ? navigator.getGamepads() : [];
    let connected = false;
    let name = '';
    for (const gp of gamepads) {
      if (gp && gp.connected) {
        connected = true;
        name = gp.id || 'GAMEPAD';
        break;
      }
    }
    if (connected) {
      badge.textContent = `CONNECTED: ${name.slice(0, 16).toUpperCase()}`;
      badge.className = 'text-[9px] font-orbitron font-bold px-2 py-0.5 rounded-full bg-cosmic-mint/20 text-cosmic-mint border border-cosmic-mint/40 animate-pulse';
    } else {
      badge.textContent = 'DISCONNECTED';
      badge.className = 'text-[9px] font-orbitron font-bold px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700';
    }
  }

  document.getElementById('btnSettingsClose')?.addEventListener('click', () => {
    document.getElementById('modalSettings')?.classList.add('hidden');
  });

  document.querySelectorAll('.btn-setting-shake').forEach(btn => {
    btn.addEventListener('click', (e) => {
      audio.init();
      const val = parseInt(e.currentTarget.getAttribute('data-val'), 10);
      saveSystem.updateSettings({ screenShake: val });
      syncSettingsUI();
    });
  });

  document.querySelectorAll('.btn-setting-part').forEach(btn => {
    btn.addEventListener('click', (e) => {
      audio.init();
      const val = e.currentTarget.getAttribute('data-val');
      saveSystem.updateSettings({ particleDensity: val });
      syncSettingsUI();
    });
  });

  document.querySelectorAll('.btn-setting-threat').forEach(btn => {
    btn.addEventListener('click', (e) => {
      audio.init();
      const val = (e.currentTarget.getAttribute('data-val') === 'true');
      saveSystem.updateSettings({ threatRings: val });
      syncSettingsUI();
    });
  });

  document.querySelectorAll('.btn-setting-text').forEach(btn => {
    btn.addEventListener('click', (e) => {
      audio.init();
      const val = e.currentTarget.getAttribute('data-val');
      saveSystem.updateSettings({ floatingText: val });
      syncSettingsUI();
    });
  });

  document.querySelectorAll('.btn-setting-style').forEach(btn => {
    btn.addEventListener('click', (e) => {
      audio.init();
      const val = e.currentTarget.getAttribute('data-val');
      if (saveSystem.setArtStyle) {
        saveSystem.setArtStyle(val);
      } else {
        saveSystem.updateSettings({ artStyle: val });
      }
      engine.artStyle = val;
      syncSettingsUI();
      const toastMap = { astral: '💎 ASTRAL', vector: '🕹️ VECTOR', comic: '💥 COMIC' };
      engine.showToast(`🎨 ART STYLE: ${toastMap[val] || val.toUpperCase()}`, '#00e5ff');
    });
  });

  window.addEventListener('gamepadconnected', () => {
    updateGamepadBadge();
    engine.showToast('🎮 GAMEPAD CONTROLLER DETECTED!', '#00e5ff');
  });
  window.addEventListener('gamepaddisconnected', () => {
    updateGamepadBadge();
    engine.showToast('GAMEPAD DISCONNECTED', '#ff3366');
  });

  // ==================== BATTLE CARD MODAL ====================
  let activeBattleCardEngine = engine;

  function createHistoricalEngine(run) {
    const isWin = !!run.victory;
    const modeUpper = (run.mode || '').toUpperCase();
    return {
      isHistoricalRun: true,
      mode: run.mode,
      currentPlanetId: run.planetId || 1,
      state: isWin ? 'VICTORY' : 'DEFEAT',
      victory: isWin,
      isTitanProtocolMode: modeUpper === 'TITAN' || modeUpper === 'TITAN PROTOCOL',
      isEndlessMode: modeUpper === 'ENDLESS',
      isDailyAnomalyMode: modeUpper === 'DAILY' || modeUpper === 'DAILY ANOMALY',
      isIncursion: modeUpper === 'INCURSION',
      currentWave: run.waveReached || 1,
      totalWaves: 3,
      score: run.score || 0,
      maxCombo: run.maxCombo || 1,
      enemiesVaporized: run.enemiesVaporized || Math.round((run.score || 1000) / 75),
      planet: {
        coreHp: isWin ? 100 : 0,
        maxCoreHp: 100
      },
      selectedChassis: run.chassis || 'striker',
      selectedWingman: run.wingman || 'aegis',
      equippedRelics: run.relics || [],
      synergies: run.synergies || [],
      telemetryHistory: Array.isArray(run.telemetryHistory) && run.telemetryHistory.length > 0 ? run.telemetryHistory : [
        { time: 0, combo: 1, integrity: 100 },
        { time: 40, combo: Math.max(1, Math.round((run.maxCombo || 1) * 0.7)), integrity: 90 },
        { time: 80, combo: run.maxCombo || 1, integrity: isWin ? 100 : 25 }
      ],
      damageSources: run.damageSources || { turret: 55, nova: 30, wingman: 15 }
    };
  }

  function openBattleCardModal() {
    audio.init();
    activeBattleCardEngine = engine;
    const canvas = document.getElementById('battleCardCanvas');
    if (canvas) {
      BattleCardGenerator.renderInto(canvas, activeBattleCardEngine, saveSystem);
    }
    document.getElementById('modalBattleCard')?.classList.remove('hidden');
  }

  function openHistoricalBattleCard(run) {
    audio.init();
    activeBattleCardEngine = createHistoricalEngine(run);
    const canvas = document.getElementById('battleCardCanvas');
    if (canvas) {
      BattleCardGenerator.renderInto(canvas, activeBattleCardEngine, saveSystem);
    }
    document.getElementById('modalBattleCard')?.classList.remove('hidden');
  }

  document.getElementById('btnVictoryBattleCard')?.addEventListener('click', openBattleCardModal);
  document.getElementById('btnDefeatBattleCard')?.addEventListener('click', openBattleCardModal);
  document.getElementById('btnCodexBattleCard')?.addEventListener('click', openBattleCardModal);
  document.getElementById('btnBattleCardClose')?.addEventListener('click', () => {
    document.getElementById('modalBattleCard')?.classList.add('hidden');
  });

  document.getElementById('btnDownloadCard')?.addEventListener('click', () => {
    audio.init();
    const canvas = document.getElementById('battleCardCanvas');
    if (canvas) {
      BattleCardGenerator.downloadCard(canvas, `spark-panic-card-${activeBattleCardEngine.score || 'record'}.png`);
      engine.showToast('BATTLE CARD PNG DOWNLOADED!', '#ffd700');
    }
  });

  document.getElementById('btnCopyCard')?.addEventListener('click', async () => {
    audio.init();
    const canvas = document.getElementById('battleCardCanvas');
    const label = document.getElementById('copyCardLabel');
    if (canvas) {
      const res = await BattleCardGenerator.copyCardToClipboard(canvas, activeBattleCardEngine);
      if (label) {
        label.textContent = res === 'IMAGE_COPIED' ? '✓ IMAGE COPIED!' : '✓ STATS COPIED!';
        setTimeout(() => { if (label) label.textContent = 'COPY IMAGE / STATS'; }, 2200);
      }
      engine.showToast(res === 'IMAGE_COPIED' ? 'BATTLE CARD COPIED TO CLIPBOARD!' : 'TACTICAL STATS COPIED!', '#00e676');
    }
  });

  // Start in Title Command Deck view
  openTitle();

  // YouTube Playables SDK ready hooks
  try {
    if (typeof window !== 'undefined' && window.ytgame?.game) {
      window.ytgame.game.firstFrameReady?.();
      window.ytgame.game.gameReady?.();
    }
  } catch (e) {
    console.debug('YouTube Playables notice:', e);
  }

  // Main Game Loop (requestAnimationFrame)
  let lastTime = performance.now();

  function gameLoop(now) {
    const dt = Math.min((now - lastTime) / 1000, 0.05);
    lastTime = now;

    engine.update(dt);
    engine.render();

    requestAnimationFrame(gameLoop);
  }

  requestAnimationFrame(gameLoop);
});
